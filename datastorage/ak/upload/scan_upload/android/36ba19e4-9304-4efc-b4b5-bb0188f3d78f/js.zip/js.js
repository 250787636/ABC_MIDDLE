
'use strict';
var pkgName = "";
var isRunningForeground = true;
var lastTime = 0;
var activityStack = {};
var switchStatus = 300;
var fridaManager = null;
function showStacks() {
    return Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Exception").$new());
}
function writeFile(content) {
    try{

         var now = new Date();
         var hour = now.getHours();//得到小时
         var minu = now.getMinutes();//得到分钟
         var sec = now.getSeconds();//得到秒
         var file = new File("/data/user/0/"+pkgName+"/activity.txt","a");//a+表示追加内容，此处的模式和c语言的fopen函数模式相同
         file.write("[ "+hour+":"+minu+":"+sec + "] "+content+"\n");
         file.flush();
         file.close();
     }catch(e){
     }
}
function readFile() {
    var result = "";
    try{
        var FileReader = Java.use('java.io.FileReader');
        var fr = FileReader.$new('/data/local/tmp/bangcle_config/test_pkg_name')
        var BufferedReader = Java.use('java.io.BufferedReader');
        var br = BufferedReader.$new(fr);
        while((result = br.readLine())!= null){
            writeFile("result = "+ result);
            return result;
        }
     }catch(e){
         writeFile("isFilter comein"+e);
     }
     return result;
}
function isnull(argument){
    if(argument == null){
        return true;
    }
    return false;
}

function existFile(filename){
    try{
        var file = new File(filename,"r");//a+表示追加内容，此处的模式和c语言的fopen函数模式相同
        if(file != null){
            writeFile("isFilter comein"+file);
            return true;
        }
    }catch( e){
        writeFile("isFilter comein"+e);
    }
    return false;
}

setInterval(function() {
    try{
        if(fridaManager != null){
            for (var time in activityStack) {
                var curTime = new Date().getTime();
                if(activityStack[time] == 'onResume'){
                    if(!isRunningForeground && curTime - lastTime > switchStatus){
                        writeFile("切换到前台");
                        isRunningForeground = true;
                        activityStack = {};
                        fridaManager.get().addDetailInfo("BEFORE",null,null,null,"android.app.Activity","onResume", '',"ACTIVITY_INFO",5,' ',0);
                    }
                }else{
                    if(isRunningForeground && curTime - lastTime > switchStatus){
                        writeFile("切换到后台");
                        isRunningForeground = false;
                        activityStack = {};
                        fridaManager.get().addDetailInfo("BEFORE",null,null,null,"android.app.Activity","onPause", '',"ACTIVITY_INFO",5,' ',0);
                    }
                }
            }   
        }
    }catch(e){
        writeFile(e);
    }
}, 100);
setTimeout(function() {
    if (Java.available) {
        Java.perform(function () {
            var currentApplication = Java.use("android.app.ActivityThread").currentApplication();
            var context = currentApplication.getApplicationContext();
            pkgName = context.getPackageName();
            var dexPath = "/data/local/tmp/dex_dir/add.dex";
            var entryClass = "com.testhook.FridaManager";
            Java.openClassFile(dexPath).load();
            writeFile("inject " + dexPath +" to " + pkgName + " successfully!");
            fridaManager = Java.use(entryClass).$new();
            fridaManager.get().init(pkgName);
            fridaManager.get().setContext(context);

            var Object_class= Java.use("java.lang.Object");
            var Boolean_class= Java.use("java.lang.Boolean");
            var Char_class = Java.use("java.lang.Character");
            var Double_class = Java.use("java.lang.Double");
            var Float_class = Java.use("java.lang.Float");
            var Integer_class = Java.use("java.lang.Integer");
            var Long_class = Java.use("java.lang.Long");
            var Short_class = Java.use("java.lang.Short");
            var Byte_class = Java.use("java.lang.Byte");
            var ArrayList_class = Java.use("java.util.ArrayList");

            var Window = Java.use("android.view.Window");
            try{
               try{
                    var FileWriter = Java.use("java.io.FileWriter");
                    FileWriter.$init.overload('java.io.File','boolean').implementation=function(param_1,param_2){
                        writeFile("FileWriter BEFORE "+param_1);
                        var ret = this.$init(param_1, param_2);
                        if(param_1.getAbsolutePath().indexOf("/storage/emulated/0") >= 0){
                            var arguments_1_object = Boolean_class.$new(param_2)
                            var arguments_list = Java.array("Ljava.lang.Object;",[param_1, arguments_1_object]);
                            var this_Object = Java.cast(this,Object_class);
                            var ret_Object;
                            if(ret != null)
                                ret_Object = ret;
                            else
                                ret_Object = null;
                            fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"java.io.FileWriter","$init","(Ljava/io/File;Z)V","WRITE_EXTERNAL_STORAGE",0, showStacks(),0)
                        }
                        return ret;
                    };
                    var FileOutputStream = Java.use("java.io.FileOutputStream");
                    FileOutputStream.$init.overload('java.io.File').implementation=function(param_1){
                        writeFile("FileOutputStream BEFORE "+param_1);
                        var ret = this.$init(param_1);
                        if(param_1.getAbsolutePath().indexOf("/storage/emulated/0") >= 0){
                            var arguments_list = Java.array("Ljava.lang.Object;",[param_1]);
                            var this_Object = Java.cast(this,Object_class);
                            var ret_Object;
                            if(ret != null)
                                ret_Object = ret;
                            else
                                ret_Object = null;
                            fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"java.io.FileOutputStream","$init","(Ljava/io/File)V","WRITE_EXTERNAL_STORAGE",0, showStacks(),0)
                        }
                        return ret;
                    };
                    var FileInputStream = Java.use("java.io.FileInputStream");
                    FileInputStream.$init.overload('java.io.File').implementation=function(param_1){
                        writeFile("FileInputStream BEFORE "+param_1);
                        var ret = this.$init(param_1);
                        if(param_1.getAbsolutePath().indexOf("/storage/emulated/0") >= 0){
                            var arguments_list = Java.array("Ljava.lang.Object;",[param_1]);
                            var this_Object = Java.cast(this,Object_class);
                            var ret_Object;
                            if(ret != null)
                                ret_Object = ret;
                            else
                                ret_Object = null;
                            fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"java.io.FileInputStream","$init","(Ljava/io/File)V","READ_EXTERNAL_STORAGE",0, showStacks(),0)
                        }
                        return ret;
                    };
                    var FileReader = Java.use("java.io.FileReader");
                    FileReader.$init.overload('java.io.File').implementation=function(param_1){
                        writeFile("FileReader BEFORE "+param_1);
                        var ret = this.$init(param_1);
                        if(param_1.getAbsolutePath().indexOf("/storage/emulated/0") >= 0){
                            var arguments_list = Java.array("Ljava.lang.Object;",[param_1]);
                            var this_Object = Java.cast(this,Object_class);
                            var ret_Object;
                            if(ret != null)
                                ret_Object = ret;
                            else
                                ret_Object = null;
                            fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"java.io.FileReader","$init","(Ljava/io/File;Z)V","READ_EXTERNAL_STORAGE",0, showStacks(),0)
                        }
                        return ret;
                    };
                }catch(e){
                writeFile(e);
                }
            } catch(e) {
                writeFile(e);
            }
            try{
               try{
                    var SQLiteDatabase = Java.use("android.database.sqlite.SQLiteDatabase");
                    SQLiteDatabase.insert.overload('java.lang.String', 'java.lang.String', 'android.content.ContentValues').implementation = function () {
                        writeFile(" SQLiteDatabase.insert BEFORE");
                        var ret = this.insert(arguments[0], arguments[1], arguments[2]);
                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0], arguments[1], arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Long_class.$new(ret);
                        else
                            ret_Object = null;
                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"android.database.sqlite.SQLiteDatabase","insert","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/ContentValues)LL","",4, showStacks(),0)
                        return ret;
                    }
                    SQLiteDatabase.execSQL.overload('java.lang.String').implementation = function () {
                        writeFile(" SQLiteDatabase.execSQL BEFORE");
                        var ret = this.execSQL(arguments[0]);
                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else
                            ret_Object = null;
                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"android.database.sqlite.SQLiteDatabase","execSQL","(Ljava/lang/String)V","",4, showStacks(),0)
                        return ret;
                    }
                }catch(e){
                writeFile(e);
                }
            } catch(e) {
                writeFile(e);
            }
            try{
               try{
                    var AbstractDao = Java.use("org.greenrobot.greendao.AbstractDao");
                    AbstractDao.insert.overload('java.lang.Object').implementation = function () {
                        writeFile(" StandardDatabase.insert BEFORE");
                        var ret = this.insert(arguments[0]);
                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Long_class.$new(ret);
                        else
                            ret_Object = null;
                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"org.greenrobot.greendao.AbstractDao","insert","(Ljava/lang/Object)LL","",4, showStacks(),0)
                        return ret;
                    }
                    AbstractDao.queryBuilder.overload().implementation = function () {
                        writeFile(" StandardDatabase.queryBuilder AFTER");
                        var ret = this.queryBuilder();
                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else
                            ret_Object = null;
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"org.greenrobot.greendao.AbstractDao","queryBuilder","()Ljava/lang/Object","",4, showStacks(),0)
                        return ret;
                    }
                }catch(e){
                writeFile(e);
                }
            } catch(e) {
                writeFile(e);
            }
            try {
                try{
                    var SharedPreferencesImpl = Java.use("android.app.SharedPreferencesImpl");
                    SharedPreferencesImpl.getString.overload('java.lang.String','java.lang.String').implementation = function () {
                    writeFile(" SharedPreferencesImpl.getString AFTER");
                    var ret = this.getString(arguments[0],arguments[1]);
                    var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                    var this_Object = Java.cast(this,Object_class);
                    var ret_Object;
                    if(ret != null)
                        ret_Object = ret;
                    else
                        ret_Object = null;
                    fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"android.app.SharedPreferencesImpl","getString","(Ljava/lang/String;Ljava/lang/String)Ljava/lang/String","",4, showStacks(),0)
                    return ret;
                    }
                }catch(e){
                writeFile(e);
                }
                try{
                    var EditorImpl = Java.use("android.app.SharedPreferencesImpl$EditorImpl");
                    EditorImpl.putString.overload('java.lang.String','java.lang.String').implementation = function () {
                    writeFile(" SharedPreferencesImpl.putString BEFORE");
                    var ret = this.putString(arguments[0],arguments[1]);
                    var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                    var this_Object = Java.cast(this,Object_class);
                    var ret_Object;
                    if(ret != null)
                        ret_Object = ret;
                    else
                        ret_Object = null;
                    fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"android.app.SharedPreferencesImpl$EditorImpl","putString","(Ljava/lang/String;Ljava/lang/String)Ljava/lang/String","",4, showStacks(),0)
                    return ret;
                    }
                }catch(e){
                writeFile(e);
                }
            } catch(e) {
                writeFile(e);
            }
            try {
                try{
                    var Response = Java.use("okhttp3.Response");
                    Response.body.overload().implementation = function () {
                    var ret = this.body();
                    var stack = showStacks();
                    if(stack.indexOf("okhttp3.RealCall.getResponseWithInterceptorChain") < 0){
                        var request = "url="+this.request().url() + "\r\n\"header=" +this.headers();
                        var arguments_list = Java.array("Ljava.lang.Object;",[request]);
                        var this_Object = Java.cast(this,Object_class);
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(this.peekBody(32 * 1024),Object_class);
                        else
                            ret_Object = null;
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"okhttp3.Response","body","()Lokhttp3.ResponseBody","INTERNET",1, stack,0)
                    }
                    return ret;
                    }
                }catch(e){
                writeFile(e);
                }
            } catch(e) {
                writeFile(e);
            }
            try{
                var ActivityThread = Java.use('android.app.ActivityThread');
                try{
                       ActivityThread.performLaunchActivity.overload('android.app.ActivityThread$ActivityClientRecord', 'android.content.Intent').implementation = function () {
                           writeFile("Hook call performLaunchActivity BEFORE");
                           var ret = this.performLaunchActivity(arguments[0],arguments[1]);
                           var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                           var this_Object = Java.cast(this, Object_class);
                           var ret_Object;
                           if(ret != null)
                              ret_Object = ret;
                           else
                              ret_Object = null;
                           fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, ret_Object,"android.app.ActivityThread","performLaunchActivity","(Landroid/app/ActivityThread$ActivityClientRecord;Landroid/content/Intent)Landroid/app/Activity","",0,showStacks(),1)
                           return ret;
                        }
                    }
                    catch(e){
                       writeFile(e)
                    }
                }catch(e){
                writeFile(e)
            }
            try{
                var Activity = Java.use('android.app.Activity');
                try{
                    Activity.startActivity.overload('android.content.Intent').implementation = function () {
                    writeFile("Hook call startActivity BEFORE");
                    this.startActivity(arguments[0]);
                    if(arguments[0].toString().indexOf(pkgName) < 0){
                        writeFile("startActivity "+arguments[0].toString());
                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);
                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.Activity","startActivity","(Landroid/content/Intent;)V","",0,showStacks(),1)
                        }
                    }
                }
                catch(e){
                    writeFile(e)
                }
                try{
                    Activity.onResume.overload().implementation = function () {
                        var curTime = new Date().getTime();
                        writeFile("Hook call Activity onResume "+this.toString()+" timeStap = "+curTime);
                        var ret = this.onResume();
                        if(curTime - lastTime < switchStatus){
                            writeFile("clear activityStack");
                            activityStack={}
                        }
                        activityStack[curTime] = 'onResume'
                        lastTime = curTime
                        return ret;
                    }
                }catch(e){
                    writeFile(e)
                }
                try{
                    Activity.onPause.overload().implementation = function () {
                        var curTime = new Date().getTime();
                        writeFile("Hook call Activity onPause "+this.toString()+" timeStap = "+curTime);
                        var ret = this.onPause();
                        if(curTime - lastTime < switchStatus){
                            writeFile("clear activityStack");
                            activityStack={}
                        }
                        activityStack[curTime] = 'onPause'
                        lastTime = curTime
                        return ret;
                    }
                }catch(e){
                    writeFile(e)
                }
            }catch(e){
                writeFile(e)
            }
            try{
                var ClipboardManager = Java.use('android.content.ClipboardManager');
                try{
                        ClipboardManager.getPrimaryClip.overload().implementation = function () {
                        writeFile("Hook call getPrimaryClip BEFORE");
                        var ret = this.getPrimaryClip();
                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this, Object_class);
                        var ret_Object;
                        if(ret != null)
                           ret_Object = ret;
                        else
                           ret_Object = null;
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"android.content.ClipboardManager","getPrimaryClip","()V","",0,showStacks(),0)
                        return ret;
                    }
                }
                catch(e){
                    writeFile(e)
                }
               }catch(e){
                   writeFile(e)
               }
            try{
                var ApplicationPackageManager = Java.use('android.app.ApplicationPackageManager');
                try{
                    ApplicationPackageManager.getInstalledPackages.overload('int').implementation = function () {
                        writeFile("Hook call ApplicationPackageManager getInstalledPackages Before");
                        var arguments_0_object = Integer_class.$new(arguments[0]);
                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var ret = this.getInstalledPackages(arguments[0]);
                        var this_Object = Java.cast(this,Object_class);
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret,"android.app.ApplicationPackageManager","getInstalledPackages","(I)Ljava/util/List;","",0,showStacks(),0)
                        writeFile("Hook call ApplicationPackageManager getInstalledPackages Over");
                        return ret;
                    }
                }catch(e){
                     writeFile(e)
                 }
//                try{
//                    ApplicationPackageManager.getInstalledApplications.overload('int').implementation = function () {
//                        writeFile("Hook call ApplicationPackageManager getInstalledApplications Before");
//                        var arguments_0_object = Integer_class.$new(arguments[0]);
//                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
//                        var ret = this.getInstalledApplications(arguments[0]);
//                        var this_Object = Java.cast(this,Object_class);
//                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret,"android.app.ApplicationPackageManager","getInstalledApplications","(I)Ljava/util/List;","",0,showStacks(),0)
//                        writeFile("Hook call ApplicationPackageManager getInstalledApplications Over");
//                        return ret;
//                    }
//                }catch(e){
//                  writeFile(e)
//              }
            }catch(e){
                writeFile(e)
            }
            try{
                var HttpURLConnectionImpl = Java.use('com.android.okhttp.internal.huc.HttpURLConnectionImpl');

                var Modifier_class = Java.use("java.lang.reflect.Modifier");
                Modifier_class.isNative.overload('int').implementation = function () {
                    writeFile("come in")    
                    var ret = this.isNative(0);    
                    return ret;
                }

            }catch(e){
                writeFile(e)
            }            
            try{

                var AccountManager = Java.use('android.accounts.AccountManager');

                

                try{
                    AccountManager.addAccount.overload('java.lang.String','java.lang.String','[Ljava.lang.String;','android.os.Bundle','android.app.Activity','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call addAccount GET_ACCOUNTS Before");

                        var ret = this.addAccount(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6]);

                        
                        if (!isnull(arguments[2])){
                             var arguments_2_object = ArrayList_class.$new();
                             arguments[2].forEach( function(item){
                                arguments_2_object.add(item)
                             })

                        }else{
                            var arguments_2_object = arguments[2]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object,arguments[3],arguments[4],arguments[5],arguments[6]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","addAccount","(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Landroid/os/Bundle;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.addAccountExplicitly.overload('android.accounts.Account','java.lang.String','android.os.Bundle').implementation = function () {
                        writeFile("Hook call addAccountExplicitly AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.addAccountExplicitly(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","addAccountExplicitly","(Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;)Z","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }




                try{
                    AccountManager.addOnAccountsUpdatedListener.overload('android.accounts.OnAccountsUpdateListener','android.os.Handler','boolean').implementation = function () {
                        writeFile("Hook call addOnAccountsUpdatedListener GET_ACCOUNTS Before");

                        var ret = this.addOnAccountsUpdatedListener(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","addOnAccountsUpdatedListener","(Landroid/accounts/OnAccountsUpdateListener;Landroid/os/Handler;Z)V","GET_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.blockingGetAuthToken.overload('android.accounts.Account','java.lang.String','boolean').implementation = function () {
                        writeFile("Hook call blockingGetAuthToken GET_ACCOUNTS Before");

                        var ret = this.blockingGetAuthToken(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","blockingGetAuthToken","(Landroid/accounts/Account;Ljava/lang/String;Z)Ljava/lang/String;","USE_CREDENTIALS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.clearPassword.overload('android.accounts.Account').implementation = function () {
                        writeFile("Hook call clearPassword MANAGE_ACCOUNTS Before");

                        var ret = this.clearPassword(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","clearPassword","(Landroid/accounts/Account;)V","MANAGE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.confirmCredentials.overload('android.accounts.Account','android.os.Bundle','android.app.Activity','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call confirmCredentials GET_ACCOUNTS Before");

                        var ret = this.confirmCredentials(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","confirmCredentials","(Landroid/accounts/Account;Landroid/os/Bundle;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.editProperties.overload('java.lang.String','android.app.Activity','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call editProperties GET_ACCOUNTS Before");

                        var ret = this.editProperties(arguments[0],arguments[1],arguments[2],arguments[3]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","editProperties","(Ljava/lang/String;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    AccountManager.getAccounts.overload().implementation = function () {
                        writeFile("Hook call getAccounts GET_ACCOUNTS After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getAccounts();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null){
                            ret_Object = ArrayList_class.$new();
                            ret.forEach( function(item){
                                ret_Object.add(item)
                             })
                        }
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.accounts.AccountManager","getAccounts","()[Landroid/accounts/Account;","GET_ACCOUNTS",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    AccountManager.getAccountsByType.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getAccountsByType GET_ACCOUNTS After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);

                        var ret = this.getAccountsByType(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null){
                            ret_Object = ArrayList_class.$new();
                            ret.forEach( function(item){
                                ret_Object.add(item)
                             })
                        }
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.accounts.AccountManager","getAccountsByType","(Ljava/lang/String;)[Landroid/accounts/Account;","GET_ACCOUNTS",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.getAccountsByTypeAndFeatures.overload('java.lang.String','[Ljava.lang.String;','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call getAccountsByTypeAndFeatures GET_ACCOUNTS Before");

                        var ret = this.getAccountsByTypeAndFeatures(arguments[0],arguments[1],arguments[2],arguments[3]);

                        
                        if (!isnull(arguments[1])){
                             var arguments_1_object = ArrayList_class.$new();
                             arguments[1].forEach( function(item){
                                arguments_1_object.add(item)
                             })

                        }else{
                            var arguments_1_object = arguments[1]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2],arguments[3]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","getAccountsByTypeAndFeatures","(Ljava/lang/String;[Ljava/lang/String;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.getAuthToken.overload('android.accounts.Account','java.lang.String','boolean','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call getAuthToken GET_ACCOUNTS Before");

                        var ret = this.getAuthToken(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object,arguments[3],arguments[4]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","getAuthToken","(Landroid/accounts/Account;Ljava/lang/String;ZLandroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","USE_CREDENTIALS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.getAuthTokenByFeatures.overload('java.lang.String','java.lang.String','[Ljava.lang.String;','android.app.Activity','android.os.Bundle','android.os.Bundle','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call getAuthTokenByFeatures GET_ACCOUNTS Before");

                        var ret = this.getAuthTokenByFeatures(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6],arguments[7]);

                        
                        if (!isnull(arguments[2])){
                             var arguments_2_object = ArrayList_class.$new();
                             arguments[2].forEach( function(item){
                                arguments_2_object.add(item)
                             })

                        }else{
                            var arguments_2_object = arguments[2]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object,arguments[3],arguments[4],arguments[5],arguments[6],arguments[7]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","getAuthTokenByFeatures","(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Landroid/app/Activity;Landroid/os/Bundle;Landroid/os/Bundle;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.getPassword.overload('android.accounts.Account').implementation = function () {
                        writeFile("Hook call getPassword AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.getPassword(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","getPassword","(Landroid/accounts/Account;)Ljava/lang/String;","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.getUserData.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call getUserData AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.getUserData(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","getUserData","(Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.hasFeatures.overload('android.accounts.Account','[Ljava.lang.String;','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call hasFeatures GET_ACCOUNTS Before");

                        var ret = this.hasFeatures(arguments[0],arguments[1],arguments[2],arguments[3]);

                        
                        if (!isnull(arguments[1])){
                             var arguments_1_object = ArrayList_class.$new();
                             arguments[1].forEach( function(item){
                                arguments_1_object.add(item)
                             })

                        }else{
                            var arguments_1_object = arguments[1]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2],arguments[3]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","hasFeatures","(Landroid/accounts/Account;[Ljava/lang/String;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.invalidateAuthToken.overload('java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call invalidateAuthToken USE_CREDENTIALS Before");

                        var ret = this.invalidateAuthToken(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","invalidateAuthToken","(Ljava/lang/String;Ljava/lang/String;)V","MANAGE_ACCOUNTS|USE_CREDENTIALS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.peekAuthToken.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call peekAuthToken AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.peekAuthToken(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","peekAuthToken","(Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.removeAccount.overload('android.accounts.Account','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call removeAccount GET_ACCOUNTS Before");

                        var ret = this.removeAccount(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","removeAccount","(Landroid/accounts/Account;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.setAuthToken.overload('android.accounts.Account','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call setAuthToken AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.setAuthToken(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","setAuthToken","(Landroid/accounts/Account;Ljava/lang/String;Ljava/lang/String;)V","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.setPassword.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call setPassword AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.setPassword(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","setPassword","(Landroid/accounts/Account;Ljava/lang/String;)V","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.setUserData.overload('android.accounts.Account','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call setUserData AUTHENTICATE_ACCOUNTS Before");

                        var ret = this.setUserData(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","setUserData","(Landroid/accounts/Account;Ljava/lang/String;Ljava/lang/String;)V","AUTHENTICATE_ACCOUNTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AccountManager.updateCredentials.overload('android.accounts.Account','java.lang.String','android.os.Bundle','android.app.Activity','android.accounts.AccountManagerCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call updateCredentials GET_ACCOUNTS Before");

                        var ret = this.updateCredentials(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.accounts.AccountManager","updateCredentials","(Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;","MANAGE_ACCOUNTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Vibrator = Java.use('android.os.Vibrator');

                

                try{
                    Vibrator.cancel.overload().implementation = function () {
                        writeFile("Hook call cancel VIBRATE Before");

                        var ret = this.cancel();




                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.os.Vibrator","cancel","()V","VIBRATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var MediaPlayer = Java.use('android.media.MediaPlayer');

                

                try{
                    MediaPlayer.pause.overload().implementation = function () {
                        writeFile("Hook call pause WAKE_LOCK Before");

                        var ret = this.pause();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","pause","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    MediaPlayer.release.overload().implementation = function () {
                        writeFile("Hook call release WAKE_LOCK Before");

                        var ret = this.release();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","release","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    MediaPlayer.reset.overload().implementation = function () {
                        writeFile("Hook call reset WAKE_LOCK Before");

                        var ret = this.reset();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","reset","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    MediaPlayer.setWakeMode.overload('android.content.Context','int').implementation = function () {
                        writeFile("Hook call setWakeMode WAKE_LOCK Before");

                        var ret = this.setWakeMode(arguments[0],arguments[1]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","setWakeMode","(Landroid/content/Context;I)V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    MediaPlayer.start.overload().implementation = function () {
                        writeFile("Hook call start RECORD_AUDIO Before");

                        var ret = this.start();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","start","()V","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    MediaPlayer.stop.overload().implementation = function () {
                        writeFile("Hook call stop WAKE_LOCK Before");

                        var ret = this.stop();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaPlayer","stop","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var SensorManager = Java.use('android.hardware.SensorManager');

                

                try{
                    SensorManager.getSensorList.overload('int').implementation = function () {
                        writeFile("Hook call getSensorList SensorManager Before");

                        var ret = this.getSensorList(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.SensorManager","getSensorList","(I)Ljava/util/List;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SensorManager.registerListener.overload('android.hardware.SensorEventListener','android.hardware.Sensor','int').implementation = function () {
                        writeFile("Hook call registerListener BODY_SENSORS Before");

                        var ret = this.registerListener(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Integer_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.SensorManager","registerListener","(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var MediaRecorder = Java.use('android.media.MediaRecorder');

                

                try{
                    MediaRecorder.setAudioSource.overload('int').implementation = function () {
                        writeFile("Hook call setAudioSource RECORD_AUDIO Before");

                        var ret = this.setAudioSource(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.MediaRecorder","setAudioSource","(I)V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    MediaRecorder.setVideoSource.overload('int').implementation = function () {
                        writeFile("Hook call setVideoSource CAMERA After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.setVideoSource(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.media.MediaRecorder","setVideoSource","(I)V","CAMERA",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var NotificationManager = Java.use('android.app.NotificationManager');

                

                try{
                    NotificationManager.notify.overload('java.lang.String','int','android.app.Notification').implementation = function () {
                        writeFile("Hook call notify VIBRATE Before");

                        var ret = this.notify(arguments[0],arguments[1],arguments[2]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.NotificationManager","notify","(Ljava/lang/String;ILandroid/app/Notification;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var HttpsURLConnectionImpl = Java.use('com.android.okhttp.internal.huc.HttpsURLConnectionImpl');

                
            
                try{
                    HttpsURLConnectionImpl.getInputStream.overload().implementation = function () {
                        writeFile("Hook call getInputStream INTERNET After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getInputStream();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;


                        
                        return fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"com.android.okhttp.internal.huc.HttpsURLConnectionImpl","getInputStream","()Ljava/io/InputStream;","INTERNET",1,showStacks(),0)
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    HttpsURLConnectionImpl.getOutputStream.overload().implementation = function () {
                    console.log("Hook call HttpsURLConnectionImpl getOutputStream INTERNET After");
                    
                    
                    var HttpURLConnection_class = Java.use("java.net.HttpURLConnection");
                    var httpConn = Java.cast(this,HttpURLConnection_class);
                    var headers = httpConn.getRequestProperties();
                       

                    var arguments_list = Java.array("Ljava.lang.Object;",[]);

                    var ret = this.getOutputStream();

                    var this_Object = Java.cast(this,Object_class);
           
                    var ret_Object;
                    if(ret != null)
                        ret_Object = Java.cast(ret,Object_class);
                    else 
                        ret_Object = null;                    
                    var new_ret_Object = fridaManager.get().addDetailInfo_output("AFTER",arguments_list,this_Object,ret_Object,headers,"com.android.okhttp.internal.huc.HttpsURLConnectionImpl","getOutputStream","()Ljava/io/OutputStream;","INTERNET",1,showStacks(),0)
                    return new_ret_Object;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Ringtone = Java.use('android.media.Ringtone');

                

                try{
                    Ringtone.play.overload().implementation = function () {
                        writeFile("Hook call play WAKE_LOCK Before");

                        var ret = this.play();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.Ringtone","play","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Ringtone.stop.overload().implementation = function () {
                        writeFile("Hook call stop WAKE_LOCK Before");

                        var ret = this.stop();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.Ringtone","stop","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var SpeechRecognizer = Java.use('android.speech.SpeechRecognizer');

                

                try{
                    SpeechRecognizer.cancel.overload().implementation = function () {
                        writeFile("Hook call cancel RECORD_AUDIO Before");

                        var ret = this.cancel();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.SpeechRecognizer","cancel","()V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SpeechRecognizer.setRecognitionListener.overload('android.speech.RecognitionListener').implementation = function () {
                        writeFile("Hook call setRecognitionListener RECORD_AUDIO Before");

                        var ret = this.setRecognitionListener(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.SpeechRecognizer","setRecognitionListener","(Landroid/speech/RecognitionListener;)V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SpeechRecognizer.startListening.overload('android.content.Intent').implementation = function () {
                        writeFile("Hook call startListening RECORD_AUDIO Before");

                        var ret = this.startListening(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.SpeechRecognizer","startListening","(Landroid/content/Intent;)V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SpeechRecognizer.stopListening.overload().implementation = function () {
                        writeFile("Hook call stopListening RECORD_AUDIO Before");

                        var ret = this.stopListening();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.SpeechRecognizer","stopListening","()V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var SslErrorHandler = Java.use('android.webkit.SslErrorHandler');

                

                try{
                    SslErrorHandler.cancel.overload().implementation = function () {
                        writeFile("Hook call cancel RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.cancel();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.SslErrorHandler","cancel","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SslErrorHandler.proceed.overload().implementation = function () {
                        writeFile("Hook call proceed RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.proceed();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.SslErrorHandler","proceed","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var URL = Java.use('java.net.URL');

                try{
                    URL.getContent.overload().implementation = function () {
                        writeFile("Hook call getContent INTERNET Before");
                        var ret = this.getContent();

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.net.URL","getContent","()Ljava/lang/Object;","INTERNET",0,showStacks(),0)
                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }

//                try{
//                    URL.openConnection.overload().implementation = function () {
//                        writeFile("Hook call openConnection INTERNET Before");
//
//                        var ret = this.openConnection();
//                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
//                        var this_Object = Java.cast(this,Object_class);
//                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.net.URL","openConnection","()Ljava/net/URLConnection;","INTERNET",1,showStacks(),0)
//
//                        return ret;
//                    }
//
//                }catch(e){
//                    writeFile(e)
//                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var SmsManager = Java.use('android.telephony.SmsManager');



                try{
                    SmsManager.sendTextMessage.overload('java.lang.String','java.lang.String','java.lang.String','android.app.PendingIntent','android.app.PendingIntent').implementation = function () {
                        writeFile("Hook call sendTextMessage SEND_SMS Before");

                        var ret = this.sendTextMessage(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.SmsManager","sendTextMessage","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V","SEND_SMS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var CameraManager = Java.use('android.hardware.camera2.CameraManager');

                

                try{
                    CameraManager.openCamera.overload('java.lang.String','android.hardware.camera2.CameraDevice$StateCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call openCamera CAMERA Before");

                        var ret = this.openCamera(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.camera2.CameraManager","openCamera","(Ljava/lang/String;Landroid/hardware/camera2/CameraDevice$StateCallback;Landroid/os/Handler;)V","CAMERA",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Runtime = Java.use('java.lang.Runtime');

                

                try{
                    Runtime.exec.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call exec ROOT Before");

                        var ret = this.exec(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.lang.Runtime","exec","(Ljava/lang/String;)Ljava/lang/Process;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }

            }catch(e){
                writeFile(e)
            }


            
            try{

                var BluetoothDevice = Java.use('android.bluetooth.BluetoothDevice');

                

                try{
                    BluetoothDevice.createRfcommSocketToServiceRecord.overload('java.util.UUID').implementation = function () {
                        writeFile("Hook call createRfcommSocketToServiceRecord BLUETOOTH Before");

                        var ret = this.createRfcommSocketToServiceRecord(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothDevice","createRfcommSocketToServiceRecord","(Ljava/util/UUID;)Landroid/bluetooth/BluetoothSocket;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothDevice.getBluetoothClass.overload().implementation = function () {
                        writeFile("Hook call getBluetoothClass BLUETOOTH Before");

                        var ret = this.getBluetoothClass();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothDevice","getBluetoothClass","()Landroid/bluetooth/BluetoothClass;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothDevice.getBondState.overload().implementation = function () {
                        writeFile("Hook call getBondState BLUETOOTH Before");

                        var ret = this.getBondState();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothDevice","getBondState","()I","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothDevice.getName.overload().implementation = function () {
                        writeFile("Hook call getName BLUETOOTH Before");

                        var ret = this.getName();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothDevice","getName","()Ljava/lang/String;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            // try{

            //     var CookieSyncManager = Java.use('android.webkit.CookieSyncManager');

                

            //     try{
            //         CookieSyncManager.createInstance.overload('android.content.Context').implementation = function () {
            //             writeFile("Hook call createInstance RECEIVE_BOOT_COMPLETED Before");

            //             var ret = this.createInstance(arguments[0]);

                        


            //             var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
            //             var this_Object = Java.cast(this,Object_class);

            //             fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.CookieSyncManager","createInstance","(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;","",0,showStacks(),0)

                        


            //             return ret;
            //         }

            //     }catch(e){
            //         writeFile(e)
            //     }



            // }catch(e){
            //     writeFile(e)
            // }


            
            try{

                var Environment = Java.use('android.os.Environment');

                

                try{
                    Environment.getExternalStorageDirectory.overload().implementation = function () {
                        writeFile("Hook call getExternalStorageDirectory READ_EXTERNAL_STORAGE Before");

                        var ret = this.getExternalStorageDirectory();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = null;

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.os.Environment","getExternalStorageDirectory","()Ljava/io/File;","READ_EXTERNAL_STORAGE",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var BackupManager = Java.use('android.app.backup.BackupManager');

                

                try{
                    BackupManager.requestRestore.overload('android.app.backup.RestoreObserver').implementation = function () {
                        writeFile("Hook call requestRestore RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.requestRestore(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.backup.BackupManager","requestRestore","(Landroid/app/backup/RestoreObserver;)I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var VideoView = Java.use('android.widget.VideoView');

                

                try{
                    VideoView.pause.overload().implementation = function () {
                        writeFile("Hook call pause WAKE_LOCK Before");

                        var ret = this.pause();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","pause","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.resume.overload().implementation = function () {
                        writeFile("Hook call resume WAKE_LOCK Before");

                        var ret = this.resume();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","resume","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.setVideoPath.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call setVideoPath WAKE_LOCK Before");

                        var ret = this.setVideoPath(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","setVideoPath","(Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.setVideoURI.overload('android.net.Uri').implementation = function () {
                        writeFile("Hook call setVideoURI WAKE_LOCK Before");

                        var ret = this.setVideoURI(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","setVideoURI","(Landroid/net/Uri;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.start.overload().implementation = function () {
                        writeFile("Hook call start WAKE_LOCK Before");

                        var ret = this.start();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","start","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.stopPlayback.overload().implementation = function () {
                        writeFile("Hook call stopPlayback WAKE_LOCK Before");

                        var ret = this.stopPlayback();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","stopPlayback","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    VideoView.suspend.overload().implementation = function () {
                        writeFile("Hook call suspend WAKE_LOCK Before");

                        var ret = this.suspend();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.VideoView","suspend","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ContactsContract$SyncState = Java.use('android.provider.ContactsContract$SyncState');

                

                try{
                    ContactsContract$SyncState.set.overload('android.content.ContentProviderClient','android.accounts.Account','[B').implementation = function () {
                        writeFile("Hook call set READ_CONTACTS Before");

                        var ret = this.set(arguments[0],arguments[1],arguments[2]);

                        
                        if (!isnull(arguments[2])){
                             var arguments_2_object = ArrayList_class.$new();
                             arguments[2].forEach( function(item){
                                arguments_2_object.add(item)
                             })

                        }else{
                            var arguments_2_object = arguments[2]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.ContactsContract$SyncState","set","(Landroid/content/ContentProviderClient;Landroid/accounts/Account;[B)V","READ_CONTACTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var AudioRecord = Java.use('android.media.AudioRecord');

                

                try{
                    AudioRecord.startRecording.overload().implementation = function () {
                        writeFile("Hook call startRecording RECORD_AUDIO Before");

                        var ret = this.startRecording();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioRecord","startRecording","()V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioRecord.startRecording.overload('android.media.MediaSyncEvent').implementation = function () {
                        writeFile("Hook call startRecording RECORD_AUDIO Before");

                        var ret = this.startRecording(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioRecord","startRecording","(Landroid/media/MediaSyncEvent;)V","RECORD_AUDIO",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ContextWrapper = Java.use('android.content.ContextWrapper');

                

                try{
                    ContextWrapper.clearWallpaper.overload().implementation = function () {
                        writeFile("Hook call clearWallpaper SET_WALLPAPER Before");

                        var ret = this.clearWallpaper();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","clearWallpaper","()V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.removeStickyBroadcast.overload('android.content.Intent').implementation = function () {
                        writeFile("Hook call removeStickyBroadcast BROADCAST_STICKY Before");

                        var ret = this.removeStickyBroadcast(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","removeStickyBroadcast","(Landroid/content/Intent;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.sendStickyBroadcast.overload('android.content.Intent').implementation = function () {
                        writeFile("Hook call sendStickyBroadcast BROADCAST_STICKY Before");

                        var ret = this.sendStickyBroadcast(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","sendStickyBroadcast","(Landroid/content/Intent;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.sendStickyOrderedBroadcast.overload('android.content.Intent','android.content.BroadcastReceiver','android.os.Handler','int','java.lang.String','android.os.Bundle').implementation = function () {
                        writeFile("Hook call sendStickyOrderedBroadcast BROADCAST_STICKY Before");

                        var ret = this.sendStickyOrderedBroadcast(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        var arguments_3_object = Integer_class.$new(arguments[3])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments_3_object,arguments[4],arguments[5]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","sendStickyOrderedBroadcast","(Landroid/content/Intent;Landroid/content/BroadcastReceiver;Landroid/os/Handler;ILjava/lang/String;Landroid/os/Bundle;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.setWallpaper.overload('java.io.InputStream').implementation = function () {
                        writeFile("Hook call setWallpaper SET_WALLPAPER Before");

                        var ret = this.setWallpaper(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","setWallpaper","(Ljava/io/InputStream;)V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.registerReceiver.overload('android.content.BroadcastReceiver','android.content.IntentFilter').implementation = function () {
                        writeFile("Hook call registerReceiver PROCESS_OUTGOING_CALLS Before");

                        var ret = this.registerReceiver(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","registerReceiver","(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;","PROCESS_OUTGOING_CALLS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.getExternalCacheDir.overload().implementation = function () {
                        writeFile("Hook call getExternalCacheDir READ_EXTERNAL_STORAGE Before");

                        var ret = this.getExternalCacheDir();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","getExternalCacheDir","()Ljava/io/File;","READ_EXTERNAL_STORAGE",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContextWrapper.getExternalFilesDir.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getExternalFilesDir READ_EXTERNAL_STORAGE Before");

                        var ret = this.getExternalFilesDir(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContextWrapper","getExternalFilesDir","(Ljava/lang/String;)Ljava/io/File;","READ_EXTERNAL_STORAGE",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var CursorWrapper = Java.use('android.database.CursorWrapper');

                
            
                try{
                    CursorWrapper.getDouble.overload('int').implementation = function () {
                        writeFile("Hook call getDouble query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getDouble(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Double_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getDouble","(I)D","query",3,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    CursorWrapper.getFloat.overload('int').implementation = function () {
                        writeFile("Hook call getFloat query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getFloat(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Float_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getFloat","(I)F","query",3,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    CursorWrapper.getInt.overload('int').implementation = function () {
                        writeFile("Hook call getInt query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getInt(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Integer_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getInt","(I)I","query",3,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    CursorWrapper.getLong.overload('int').implementation = function () {
                        writeFile("Hook call getLong query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getLong(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Long_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getLong","(I)J","",0,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    CursorWrapper.getShort.overload('int').implementation = function () {
                        writeFile("Hook call getShort query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getShort(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Short_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getShort","(I)S","query",3,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    CursorWrapper.getString.overload('int').implementation = function () {
                        writeFile("Hook call getString query After");
                        
                        var arguments_0_object = Integer_class.$new(arguments[0])
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);

                        var ret = this.getString(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.database.CursorWrapper","getString","(I)Ljava/lang/String;","query",3,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var EventLog = Java.use('android.util.EventLog');

                

                try{
                    EventLog.getTagCode.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getTagCode RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.getTagCode(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.util.EventLog","getTagCode","(Ljava/lang/String;)I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    EventLog.getTagName.overload('int').implementation = function () {
                        writeFile("Hook call getTagName RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.getTagName(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.util.EventLog","getTagName","(I)Ljava/lang/String;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var CdmaCellLocation = Java.use('android.telephony.cdma.CdmaCellLocation');

                

                try{
                    CdmaCellLocation.getBaseStationId.overload().implementation = function () {
                        writeFile("Hook call getBaseStationId ACCESS_FINE_LOCATION Before");

                        var ret = this.getBaseStationId();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.cdma.CdmaCellLocation","getBaseStationId","()I","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    CdmaCellLocation.getNetworkId.overload().implementation = function () {
                        writeFile("Hook call getNetworkId ACCESS_FINE_LOCATION Before");

                        var ret = this.getNetworkId();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.cdma.CdmaCellLocation","getNetworkId","()I","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var URLConnection = Java.use('java.net.URLConnection');

                

                try{
                    URLConnection.connect.overload().implementation = function () {
                        writeFile("Hook call connect INTERNET Before");

                        var ret = this.connect();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.net.URLConnection","connect","()V","INTERNET",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Settings$Secure = Java.use('android.provider.Settings$Secure');

                

                try{
                    Settings$Secure.getUriFor.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getUriFor WRITE_SETTINGS Before");

                        var ret = this.getUriFor(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = null;

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$Secure","getUriFor","(Ljava/lang/String;)Landroid/net/Uri;","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$Secure.putFloat.overload('android.content.ContentResolver','java.lang.String','float').implementation = function () {
                        writeFile("Hook call putFloat WRITE_SETTINGS Before");

                        var ret = this.putFloat(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Float_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$Secure","putFloat","(Landroid/content/ContentResolver;Ljava/lang/String;F)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$Secure.putInt.overload('android.content.ContentResolver','java.lang.String','int').implementation = function () {
                        writeFile("Hook call putInt WRITE_SETTINGS Before");

                        var ret = this.putInt(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Integer_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$Secure","putInt","(Landroid/content/ContentResolver;Ljava/lang/String;I)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$Secure.putString.overload('android.content.ContentResolver','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call putString WRITE_SETTINGS Before");

                        var ret = this.putString(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$Secure","putString","(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$Secure.setLocationProviderEnabled.overload('android.content.ContentResolver','java.lang.String','boolean').implementation = function () {
                        writeFile("Hook call setLocationProviderEnabled WRITE_SETTINGS Before");

                        var ret = this.setLocationProviderEnabled(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$Secure","setLocationProviderEnabled","(Landroid/content/ContentResolver;Ljava/lang/String;Z)V","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WallpaperManager = Java.use('android.app.WallpaperManager');

                

                try{
                    WallpaperManager.clear.overload().implementation = function () {
                        writeFile("Hook call clear SET_WALLPAPER Before");

                        var ret = this.clear();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.WallpaperManager","clear","()V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WallpaperManager.setBitmap.overload('android.graphics.Bitmap').implementation = function () {
                        writeFile("Hook call setBitmap SET_WALLPAPER Before");

                        var ret = this.setBitmap(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.WallpaperManager","setBitmap","(Landroid/graphics/Bitmap;)V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WallpaperManager.setResource.overload('int').implementation = function () {
                        writeFile("Hook call setResource SET_WALLPAPER Before");

                        var ret = this.setResource(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.WallpaperManager","setResource","(I)V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WallpaperManager.setStream.overload('java.io.InputStream').implementation = function () {
                        writeFile("Hook call setStream SET_WALLPAPER Before");

                        var ret = this.setStream(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.WallpaperManager","setStream","(Ljava/io/InputStream;)V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WallpaperManager.suggestDesiredDimensions.overload('int','int').implementation = function () {
                        writeFile("Hook call suggestDesiredDimensions SET_WALLPAPER_HINTS Before");

                        var ret = this.suggestDesiredDimensions(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.WallpaperManager","suggestDesiredDimensions","(II)V","SET_WALLPAPER_HINTS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Intent = Java.use('android.content.Intent');

                

                try{
                    Intent.setAction.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call setAction CALL_PHONE Before");

                        var ret = this.setAction(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Intent","setAction","(Ljava/lang/String;)Landroid/content/Intent;","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var AudioManager = Java.use('android.media.AudioManager');

                

                try{
                    AudioManager.isBluetoothA2dpOn.overload().implementation = function () {
                        writeFile("Hook call isBluetoothA2dpOn MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.isBluetoothA2dpOn();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","isBluetoothA2dpOn","()Z","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.isWiredHeadsetOn.overload().implementation = function () {
                        writeFile("Hook call isWiredHeadsetOn MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.isWiredHeadsetOn();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","isWiredHeadsetOn","()Z","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.setBluetoothScoOn.overload('boolean').implementation = function () {
                        writeFile("Hook call setBluetoothScoOn MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.setBluetoothScoOn(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","setBluetoothScoOn","(Z)V","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.setMicrophoneMute.overload('boolean').implementation = function () {
                        writeFile("Hook call setMicrophoneMute MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.setMicrophoneMute(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","setMicrophoneMute","(Z)V","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.setMode.overload('int').implementation = function () {
                        writeFile("Hook call setMode BLUETOOTH_ADMIN Before");

                        var ret = this.setMode(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","setMode","(I)V","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.setParameters.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call setParameters MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.setParameters(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","setParameters","(Ljava/lang/String;)V","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.setSpeakerphoneOn.overload('boolean').implementation = function () {
                        writeFile("Hook call setSpeakerphoneOn MODIFY_AUDIO_SETTINGS Before");

                        var ret = this.setSpeakerphoneOn(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","setSpeakerphoneOn","(Z)V","MODIFY_AUDIO_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.startBluetoothSco.overload().implementation = function () {
                        writeFile("Hook call startBluetoothSco BLUETOOTH_ADMIN Before");

                        var ret = this.startBluetoothSco();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","startBluetoothSco","()V","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AudioManager.stopBluetoothSco.overload().implementation = function () {
                        writeFile("Hook call stopBluetoothSco BLUETOOTH_ADMIN Before");

                        var ret = this.stopBluetoothSco();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AudioManager","stopBluetoothSco","()V","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WifiManager$WifiLock = Java.use('android.net.wifi.WifiManager$WifiLock');

                

                try{
                    WifiManager$WifiLock.acquire.overload().implementation = function () {
                        writeFile("Hook call acquire WAKE_LOCK Before");

                        var ret = this.acquire();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager$WifiLock","acquire","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager$WifiLock.release.overload().implementation = function () {
                        writeFile("Hook call release WAKE_LOCK Before");

                        var ret = this.release();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager$WifiLock","release","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var KeyguardManager = Java.use('android.app.KeyguardManager');

                

                try{
                    KeyguardManager.exitKeyguardSecurely.overload('android.app.KeyguardManager$OnKeyguardExitResult').implementation = function () {
                        writeFile("Hook call exitKeyguardSecurely WAKE_LOCK Before");

                        var ret = this.exitKeyguardSecurely(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.KeyguardManager","exitKeyguardSecurely","(Landroid/app/KeyguardManager$OnKeyguardExitResult;)V","DISABLE_KEYGUARD",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WebViewDatabase = Java.use('android.webkit.WebViewDatabase');

                try{
                    WebViewDatabase.getInstance.overload('android.content.Context').implementation = function () {
                        writeFile("Hook call getInstance RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.getInstance(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebViewDatabase","getInstance","(Landroid/content/Context;)Landroid/webkit/WebViewDatabase;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Context = Java.use('android.content.Context');

                

                try{
                    Context.clearWallpaper.overload().implementation = function () {
                        writeFile("Hook call clearWallpaper SET_WALLPAPER Before");

                        var ret = this.clearWallpaper();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Context","clearWallpaper","()V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Context.removeStickyBroadcast.overload('android.content.Intent').implementation = function () {
                        writeFile("Hook call removeStickyBroadcast BROADCAST_STICKY Before");

                        var ret = this.removeStickyBroadcast(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Context","removeStickyBroadcast","(Landroid/content/Intent;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Context.sendStickyBroadcast.overload('android.content.Intent').implementation = function () {
                        writeFile("Hook call sendStickyBroadcast BROADCAST_STICKY Before");

                        var ret = this.sendStickyBroadcast(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Context","sendStickyBroadcast","(Landroid/content/Intent;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Context.sendStickyOrderedBroadcast.overload('android.content.Intent','android.content.BroadcastReceiver','android.os.Handler','int','java.lang.String','android.os.Bundle').implementation = function () {
                        writeFile("Hook call sendStickyOrderedBroadcast BROADCAST_STICKY Before");

                        var ret = this.sendStickyOrderedBroadcast(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        var arguments_3_object = Integer_class.$new(arguments[3])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments_3_object,arguments[4],arguments[5]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Context","sendStickyOrderedBroadcast","(Landroid/content/Intent;Landroid/content/BroadcastReceiver;Landroid/os/Handler;ILjava/lang/String;Landroid/os/Bundle;)V","BROADCAST_STICKY",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Context.setWallpaper.overload('java.io.InputStream').implementation = function () {
                        writeFile("Hook call setWallpaper SET_WALLPAPER Before");

                        var ret = this.setWallpaper(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.Context","setWallpaper","(Ljava/io/InputStream;)V","SET_WALLPAPER",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var TextToSpeech = Java.use('android.speech.tts.TextToSpeech');

                

                try{
                    TextToSpeech.playEarcon.overload('java.lang.String','int','java.util.HashMap').implementation = function () {
                        writeFile("Hook call playEarcon WAKE_LOCK Before");

                        var ret = this.playEarcon(arguments[0],arguments[1],arguments[2]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.tts.TextToSpeech","playEarcon","(Ljava/lang/String;ILjava/util/HashMap;)I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    TextToSpeech.speak.overload('java.lang.String','int','java.util.HashMap').implementation = function () {
                        writeFile("Hook call speak WAKE_LOCK Before");

                        var ret = this.speak(arguments[0],arguments[1],arguments[2]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.tts.TextToSpeech","speak","(Ljava/lang/String;ILjava/util/HashMap;)I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    TextToSpeech.stop.overload().implementation = function () {
                        writeFile("Hook call stop WAKE_LOCK Before");

                        var ret = this.stop();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.tts.TextToSpeech","stop","()I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    TextToSpeech.synthesizeToFile.overload('java.lang.String','java.util.HashMap','java.lang.String').implementation = function () {
                        writeFile("Hook call synthesizeToFile WAKE_LOCK Before");

                        var ret = this.synthesizeToFile(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.speech.tts.TextToSpeech","synthesizeToFile","(Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;)I","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WebSettings = Java.use('android.webkit.WebSettings');

                

                try{
                    WebSettings.setBlockNetworkLoads.overload('boolean').implementation = function () {
                        writeFile("Hook call setBlockNetworkLoads INTERNET Before");

                        var ret = this.setBlockNetworkLoads(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebSettings","setBlockNetworkLoads","(Z)V","INTERNET",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebSettings.setDefaultZoom.overload('android.webkit.WebSettings$ZoomDensity').implementation = function () {
                        writeFile("Hook call setDefaultZoom RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.setDefaultZoom(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebSettings","setDefaultZoom","(Landroid/webkit/WebSettings$ZoomDensity;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var RingtoneManager = Java.use('android.media.RingtoneManager');

                

                try{
                    RingtoneManager.getRingtone.overload('int').implementation = function () {
                        writeFile("Hook call getRingtone WAKE_LOCK Before");

                        var ret = this.getRingtone(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.RingtoneManager","getRingtone","(I)Landroid/media/Ringtone;","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    RingtoneManager.setActualDefaultRingtoneUri.overload('android.content.Context','int','android.net.Uri').implementation = function () {
                        writeFile("Hook call setActualDefaultRingtoneUri WRITE_SETTINGS Before");

                        var ret = this.setActualDefaultRingtoneUri(arguments[0],arguments[1],arguments[2]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.RingtoneManager","setActualDefaultRingtoneUri","(Landroid/content/Context;ILandroid/net/Uri;)V","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    RingtoneManager.stopPreviousRingtone.overload().implementation = function () {
                        writeFile("Hook call stopPreviousRingtone WAKE_LOCK Before");

                        var ret = this.stopPreviousRingtone();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.RingtoneManager","stopPreviousRingtone","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Location = Java.use('android.location.Location');

                
            
                try{
                    Location.getAltitude.overload().implementation = function () {
                        writeFile("Hook call getAltitude ACCESS_FINE_LOCATION After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getAltitude();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Double_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.location.Location","getAltitude","()D","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    Location.getLatitude.overload().implementation = function () {
                        writeFile("Hook call getLatitude ACCESS_FINE_LOCATION After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getLatitude();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Double_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.location.Location","getLatitude","()D","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    Location.getLongitude.overload().implementation = function () {
                        writeFile("Hook call getLongitude ACCESS_FINE_LOCATION After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getLongitude();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        

                        var ret_Object;
                        if(ret != null)
                            ret_Object = Double_class.$new(ret);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.location.Location","getLongitude","()D","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var CameraCaptureSessionImpl = Java.use('android.hardware.camera2.impl.CameraCaptureSessionImpl');

                

                try{
                    CameraCaptureSessionImpl.capture.overload('android.hardware.camera2.CaptureRequest','android.hardware.camera2.CameraCaptureSession$CaptureCallback','android.os.Handler').implementation = function () {
                        writeFile("Hook call capture CAMERA Before");

                        var ret = this.capture(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.camera2.impl.CameraCaptureSessionImpl","capture","(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I","CAMERA",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var PowerManager$WakeLock = Java.use('android.os.PowerManager$WakeLock');

                

                try{
                    PowerManager$WakeLock.acquire.overload().implementation = function () {
                        writeFile("Hook call acquire WAKE_LOCK Before");

                        var ret = this.acquire();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.os.PowerManager$WakeLock","acquire","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    PowerManager$WakeLock.release.overload().implementation = function () {
                        writeFile("Hook call release WAKE_LOCK Before");

                        var ret = this.release();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.os.PowerManager$WakeLock","release","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }
            
            try{

                var InetAddress = Java.use('java.net.InetAddress');

                

                try{
                    InetAddress.getHostAddress.overload().implementation = function () {
                        writeFile("Hook call getHostAddress ACCESS_FINE_LOCATION Before");

                        var ret = this.getHostAddress();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.net.InetAddress","getHostAddress","()Ljava/lang/String;","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }

            
            try{

                var WifiManager = Java.use('android.net.wifi.WifiManager');

                

                try{
                    WifiManager.addNetwork.overload('android.net.wifi.WifiConfiguration').implementation = function () {
                        writeFile("Hook call addNetwork CHANGE_WIFI_STATE Before");

                        var ret = this.addNetwork(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","addNetwork","(Landroid/net/wifi/WifiConfiguration;)I","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.disableNetwork.overload('int').implementation = function () {
                        writeFile("Hook call disableNetwork CHANGE_WIFI_STATE Before");

                        var ret = this.disableNetwork(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","disableNetwork","(I)Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.disconnect.overload().implementation = function () {
                        writeFile("Hook call disconnect CHANGE_WIFI_STATE Before");

                        var ret = this.disconnect();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","disconnect","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.enableNetwork.overload('int','boolean').implementation = function () {
                        writeFile("Hook call enableNetwork CHANGE_WIFI_STATE Before");

                        var ret = this.enableNetwork(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","enableNetwork","(IZ)Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.getConfiguredNetworks.overload().implementation = function () {
                        writeFile("Hook call getConfiguredNetworks ACCESS_WIFI_STATE Before");

                        var ret = this.getConfiguredNetworks();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","getConfiguredNetworks","()Ljava/util/List;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.getConnectionInfo.overload().implementation = function () {
                        writeFile("Hook call getConnectionInfo ACCESS_WIFI_STATE Before");

                        var ret = this.getConnectionInfo();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","getConnectionInfo","()Landroid/net/wifi/WifiInfo;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.getDhcpInfo.overload().implementation = function () {
                        writeFile("Hook call getDhcpInfo ACCESS_WIFI_STATE Before");

                        var ret = this.getDhcpInfo();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","getDhcpInfo","()Landroid/net/DhcpInfo;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.getScanResults.overload().implementation = function () {
                        writeFile("Hook call getScanResults ACCESS_WIFI_STATE Before");

                        var ret = this.getScanResults();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","getScanResults","()Ljava/util/List;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.getWifiState.overload().implementation = function () {
                        writeFile("Hook call getWifiState ACCESS_WIFI_STATE Before");

                        var ret = this.getWifiState();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","getWifiState","()I","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.isWifiEnabled.overload().implementation = function () {
                        writeFile("Hook call isWifiEnabled ACCESS_WIFI_STATE Before");

                        var ret = this.isWifiEnabled();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","isWifiEnabled","()Z","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.pingSupplicant.overload().implementation = function () {
                        writeFile("Hook call pingSupplicant CHANGE_WIFI_STATE Before");

                        var ret = this.pingSupplicant();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","pingSupplicant","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.reassociate.overload().implementation = function () {
                        writeFile("Hook call reassociate CHANGE_WIFI_STATE Before");

                        var ret = this.reassociate();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","reassociate","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.reconnect.overload().implementation = function () {
                        writeFile("Hook call reconnect CHANGE_WIFI_STATE Before");

                        var ret = this.reconnect();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","reconnect","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.removeNetwork.overload('int').implementation = function () {
                        writeFile("Hook call removeNetwork CHANGE_WIFI_STATE Before");

                        var ret = this.removeNetwork(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","removeNetwork","(I)Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.saveConfiguration.overload().implementation = function () {
                        writeFile("Hook call saveConfiguration CHANGE_WIFI_STATE Before");

                        var ret = this.saveConfiguration();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","saveConfiguration","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.setWifiEnabled.overload('boolean').implementation = function () {
                        writeFile("Hook call setWifiEnabled CHANGE_WIFI_STATE Before");

                        var ret = this.setWifiEnabled(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","setWifiEnabled","(Z)Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.startScan.overload().implementation = function () {
                        writeFile("Hook call startScan CHANGE_WIFI_STATE Before");

                        var ret = this.startScan();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","startScan","()Z","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager.updateNetwork.overload('android.net.wifi.WifiConfiguration').implementation = function () {
                        writeFile("Hook call updateNetwork CHANGE_WIFI_STATE Before");

                        var ret = this.updateNetwork(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager","updateNetwork","(Landroid/net/wifi/WifiConfiguration;)I","CHANGE_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var BluetoothAdapter = Java.use('android.bluetooth.BluetoothAdapter');

                

                try{
                    BluetoothAdapter.cancelDiscovery.overload().implementation = function () {
                        writeFile("Hook call cancelDiscovery BLUETOOTH_ADMIN Before");

                        var ret = this.cancelDiscovery();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","cancelDiscovery","()Z","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.enable.overload().implementation = function () {
                        writeFile("Hook call enable BLUETOOTH_ADMIN Before");

                        var ret = this.enable();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","enable","()Z","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.getAddress.overload().implementation = function () {
                        writeFile("Hook call getAddress BLUETOOTH Before");

                        var ret = this.getAddress();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","getAddress","()Ljava/lang/String;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.getBondedDevices.overload().implementation = function () {
                        writeFile("Hook call getBondedDevices BLUETOOTH Before");

                        var ret = this.getBondedDevices();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","getBondedDevices","()Ljava/util/Set;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.getName.overload().implementation = function () {
                        writeFile("Hook call getName BLUETOOTH Before");

                        var ret = this.getName();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","getName","()Ljava/lang/String;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.getScanMode.overload().implementation = function () {
                        writeFile("Hook call getScanMode BLUETOOTH Before");

                        var ret = this.getScanMode();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","getScanMode","()I","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.getState.overload().implementation = function () {
                        writeFile("Hook call getState BLUETOOTH Before");

                        var ret = this.getState();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","getState","()I","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.isDiscovering.overload().implementation = function () {
                        writeFile("Hook call isDiscovering BLUETOOTH Before");

                        var ret = this.isDiscovering();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","isDiscovering","()Z","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.isEnabled.overload().implementation = function () {
                        writeFile("Hook call isEnabled BLUETOOTH Before");

                        var ret = this.isEnabled();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","isEnabled","()Z","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.listenUsingRfcommWithServiceRecord.overload('java.lang.String','java.util.UUID').implementation = function () {
                        writeFile("Hook call listenUsingRfcommWithServiceRecord BLUETOOTH Before");

                        var ret = this.listenUsingRfcommWithServiceRecord(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","listenUsingRfcommWithServiceRecord","(Ljava/lang/String;Ljava/util/UUID;)Landroid/bluetooth/BluetoothServerSocket;","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.setName.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call setName BLUETOOTH_ADMIN Before");

                        var ret = this.setName(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","setName","(Ljava/lang/String;)Z","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    BluetoothAdapter.startDiscovery.overload().implementation = function () {
                        writeFile("Hook call startDiscovery BLUETOOTH_ADMIN Before");

                        var ret = this.startDiscovery();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothAdapter","startDiscovery","()Z","BLUETOOTH_ADMIN",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var HttpAuthHandler = Java.use('android.webkit.HttpAuthHandler');

                

                try{
                    HttpAuthHandler.cancel.overload().implementation = function () {
                        writeFile("Hook call cancel RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.cancel();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.HttpAuthHandler","cancel","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    HttpAuthHandler.proceed.overload('java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call proceed RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.proceed(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.HttpAuthHandler","proceed","(Ljava/lang/String;Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var BluetoothSocket = Java.use('android.bluetooth.BluetoothSocket');

                

                try{
                    BluetoothSocket.connect.overload().implementation = function () {
                        writeFile("Hook call connect BLUETOOTH Before");

                        var ret = this.connect();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.bluetooth.BluetoothSocket","connect","()V","BLUETOOTH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Browser = Java.use('android.provider.Browser');

                

                try{
                    Browser.addSearchUrl.overload('android.content.ContentResolver','java.lang.String').implementation = function () {
                        writeFile("Hook call addSearchUrl ACCESS_NETWORK_STATE Before");

                        var ret = this.addSearchUrl(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","addSearchUrl","(Landroid/content/ContentResolver;Ljava/lang/String;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.canClearHistory.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call canClearHistory ACCESS_NETWORK_STATE Before");

                        var ret = this.canClearHistory(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","canClearHistory","(Landroid/content/ContentResolver;)Z","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.clearHistory.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call clearHistory ACCESS_NETWORK_STATE Before");

                        var ret = this.clearHistory(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","clearHistory","(Landroid/content/ContentResolver;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.clearSearches.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call clearSearches com.android.browser.permission.READ_HISTORY_BOOKMARKS Before");

                        var ret = this.clearSearches(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","clearSearches","(Landroid/content/ContentResolver;)V","com.android.browser.permission.READ_HISTORY_BOOKMARKS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.deleteFromHistory.overload('android.content.ContentResolver','java.lang.String').implementation = function () {
                        writeFile("Hook call deleteFromHistory ACCESS_NETWORK_STATE Before");

                        var ret = this.deleteFromHistory(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","deleteFromHistory","(Landroid/content/ContentResolver;Ljava/lang/String;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.getAllBookmarks.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call getAllBookmarks ACCESS_NETWORK_STATE Before");

                        var ret = this.getAllBookmarks(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","getAllBookmarks","(Landroid/content/ContentResolver;)Landroid/database/Cursor;","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.getAllVisitedUrls.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call getAllVisitedUrls ACCESS_NETWORK_STATE Before");

                        var ret = this.getAllVisitedUrls(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","getAllVisitedUrls","(Landroid/content/ContentResolver;)Landroid/database/Cursor;","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.requestAllIcons.overload('android.content.ContentResolver','java.lang.String','android.webkit.WebIconDatabase$IconListener').implementation = function () {
                        writeFile("Hook call requestAllIcons ACCESS_NETWORK_STATE Before");

                        var ret = this.requestAllIcons(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","requestAllIcons","(Landroid/content/ContentResolver;Ljava/lang/String;Landroid/webkit/WebIconDatabase$IconListener;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.truncateHistory.overload('android.content.ContentResolver').implementation = function () {
                        writeFile("Hook call truncateHistory ACCESS_NETWORK_STATE Before");

                        var ret = this.truncateHistory(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","truncateHistory","(Landroid/content/ContentResolver;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Browser.updateVisitedHistory.overload('android.content.ContentResolver','java.lang.String','boolean').implementation = function () {
                        writeFile("Hook call updateVisitedHistory ACCESS_NETWORK_STATE Before");

                        var ret = this.updateVisitedHistory(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Browser","updateVisitedHistory","(Landroid/content/ContentResolver;Ljava/lang/String;Z)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var EventLog$Event = Java.use('android.util.EventLog$Event');

                

                try{
                    EventLog$Event.getData.overload().implementation = function () {
                        writeFile("Hook call getData RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.getData();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.util.EventLog$Event","getData","()Ljava/lang/Object;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WifiInfo = Java.use('android.net.wifi.WifiInfo');

                

                try{
                    WifiInfo.getBSSID.overload().implementation = function () {
                        writeFile("Hook call getBSSID ACCESS_WIFI_STATE Before");

                        var ret = this.getBSSID();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiInfo","getBSSID","()Ljava/lang/String;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiInfo.getIpAddress.overload().implementation = function () {
                        writeFile("Hook call getIpAddress ACCESS_WIFI_STATE Before");

                        var ret = this.getIpAddress();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiInfo","getIpAddress","()I","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiInfo.getSSID.overload().implementation = function () {
                        writeFile("Hook call getSSID ACCESS_WIFI_STATE Before");

                        var ret = this.getSSID();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiInfo","getSSID","()Ljava/lang/String;","ACCESS_WIFI_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Settings$System = Java.use('android.provider.Settings$System');

                

                try{
                    Settings$System.getUriFor.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getUriFor WRITE_SETTINGS Before");

                        var ret = this.getUriFor(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","getUriFor","(Ljava/lang/String;)Landroid/net/Uri;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$System.putConfiguration.overload('android.content.ContentResolver','android.content.res.Configuration').implementation = function () {
                        writeFile("Hook call putConfiguration WRITE_SETTINGS Before");

                        var ret = this.putConfiguration(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","putConfiguration","(Landroid/content/ContentResolver;Landroid/content/res/Configuration;)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$System.putFloat.overload('android.content.ContentResolver','java.lang.String','float').implementation = function () {
                        writeFile("Hook call putFloat WRITE_SETTINGS Before");

                        var ret = this.putFloat(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Float_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","putFloat","(Landroid/content/ContentResolver;Ljava/lang/String;F)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$System.putInt.overload('android.content.ContentResolver','java.lang.String','int').implementation = function () {
                        writeFile("Hook call putInt WRITE_SETTINGS Before");

                        var ret = this.putInt(arguments[0],arguments[1],arguments[2]);

                        var arguments_2_object = Integer_class.$new(arguments[2])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","putInt","(Landroid/content/ContentResolver;Ljava/lang/String;I)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Settings$System.putString.overload('android.content.ContentResolver','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call putString WRITE_SETTINGS Before");

                        var ret = this.putString(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","putString","(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


                try{
                    Settings$System.getString.overload('android.content.ContentResolver','java.lang.String').implementation = function () {

                    var ret = this.getString(arguments[0],arguments[1]);
                    var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                    var this_Object = Java.cast(this.class, Object_class);
                    
                   var ret_Object;
                   if(ret != null)
                       ret_Object = ret;
                   else
                       ret_Object = null;
                    fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"android.provider.Settings$System","getString","(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;","",0,showStacks(),0)
                    writeFile("call getString over");
                    return ret;
                    }
                }catch(e){
                    writeFile(e)
                }
                try{
                    var Settings$Secure = Java.use('android.provider.Settings$Secure');
                    Settings$Secure.getString.overload('android.content.ContentResolver','java.lang.String').implementation = function () {
                    var ret = this.getString(arguments[0],arguments[1]);
                    var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                    var this_Object = Java.cast(this.class, Object_class);

                    var ret_Object;
                    if(ret != null)
                        ret_Object = ret;
                    else
                        ret_Object = null;
                    
                    fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object, ret_Object,"android.provider.Settings$Secure","getString","(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;","WRITE_SETTINGS",0,showStacks(),0)
                    writeFile("call getString over");
                    return ret;
                    }
                }catch(e){
                    writeFile(e)
                }

                try{
                    Settings$System.setShowGTalkServiceStatus.overload('android.content.ContentResolver','boolean').implementation = function () {
                        writeFile("Hook call setShowGTalkServiceStatus WRITE_SETTINGS Before");

                        var ret = this.setShowGTalkServiceStatus(arguments[0],arguments[1]);

                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Settings$System","setShowGTalkServiceStatus","(Landroid/content/ContentResolver;Z)V","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WebView = Java.use('android.webkit.WebView');

                

                try{
                    WebView.addJavascriptInterface.overload('java.lang.Object','java.lang.String').implementation = function () {
                        writeFile("Hook call addJavascriptInterface RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.addJavascriptInterface(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","addJavascriptInterface","(Ljava/lang/Object;Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.clearCache.overload('boolean').implementation = function () {
                        writeFile("Hook call clearCache RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.clearCache(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","clearCache","(Z)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.clearHistory.overload().implementation = function () {
                        writeFile("Hook call clearHistory RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.clearHistory();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","clearHistory","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.clearSslPreferences.overload().implementation = function () {
                        writeFile("Hook call clearSslPreferences RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.clearSslPreferences();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","clearSslPreferences","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.clearView.overload().implementation = function () {
                        writeFile("Hook call clearView RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.clearView();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","clearView","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.debugDump.overload().implementation = function () {
                        writeFile("Hook call debugDump RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.debugDump();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","debugDump","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.destroy.overload().implementation = function () {
                        writeFile("Hook call destroy RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.destroy();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","destroy","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.documentHasImages.overload('android.os.Message').implementation = function () {
                        writeFile("Hook call documentHasImages RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.documentHasImages(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","documentHasImages","(Landroid/os/Message;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.enablePlatformNotifications.overload().implementation = function () {
                        writeFile("Hook call enablePlatformNotifications ACCESS_NETWORK_STATE Before");

                        var ret = this.enablePlatformNotifications();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","enablePlatformNotifications","()V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.freeMemory.overload().implementation = function () {
                        writeFile("Hook call freeMemory RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.freeMemory();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","freeMemory","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.goBack.overload().implementation = function () {
                        writeFile("Hook call goBack RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.goBack();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","goBack","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.goBackOrForward.overload('int').implementation = function () {
                        writeFile("Hook call goBackOrForward RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.goBackOrForward(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","goBackOrForward","(I)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.goForward.overload().implementation = function () {
                        writeFile("Hook call goForward RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.goForward();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","goForward","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.invokeZoomPicker.overload().implementation = function () {
                        writeFile("Hook call invokeZoomPicker RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.invokeZoomPicker();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","invokeZoomPicker","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.loadData.overload('java.lang.String','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call loadData RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.loadData(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","loadData","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.loadDataWithBaseURL.overload('java.lang.String','java.lang.String','java.lang.String','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call loadDataWithBaseURL RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.loadDataWithBaseURL(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","loadDataWithBaseURL","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.pauseTimers.overload().implementation = function () {
                        writeFile("Hook call pauseTimers RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.pauseTimers();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","pauseTimers","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.postUrl.overload('java.lang.String','[B').implementation = function () {
                        writeFile("Hook call postUrl RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.postUrl(arguments[0],arguments[1]);

                        
                        if (!isnull(arguments[1])){
                             var arguments_1_object = ArrayList_class.$new();
                             arguments[1].forEach( function(item){
                                arguments_1_object.add(item)
                             })

                        }else{
                            var arguments_1_object = arguments[1]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","postUrl","(Ljava/lang/String;[B)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.reload.overload().implementation = function () {
                        writeFile("Hook call reload RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.reload();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","reload","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.requestFocusNodeHref.overload('android.os.Message').implementation = function () {
                        writeFile("Hook call requestFocusNodeHref RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.requestFocusNodeHref(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","requestFocusNodeHref","(Landroid/os/Message;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.restoreState.overload('android.os.Bundle').implementation = function () {
                        writeFile("Hook call restoreState RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.restoreState(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","restoreState","(Landroid/os/Bundle;)Landroid/webkit/WebBackForwardList;","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.resumeTimers.overload().implementation = function () {
                        writeFile("Hook call resumeTimers RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.resumeTimers();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","resumeTimers","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.setNetworkAvailable.overload('boolean').implementation = function () {
                        writeFile("Hook call setNetworkAvailable RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.setNetworkAvailable(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","setNetworkAvailable","(Z)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.stopLoading.overload().implementation = function () {
                        writeFile("Hook call stopLoading RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.stopLoading();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","stopLoading","()V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.zoomIn.overload().implementation = function () {
                        writeFile("Hook call zoomIn RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.zoomIn();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","zoomIn","()Z","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.zoomOut.overload().implementation = function () {
                        writeFile("Hook call zoomOut RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.zoomOut();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","zoomOut","()Z","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.loadUrl.overload('java.lang.String','java.util.Map').implementation = function () {
                        writeFile("Hook call loadUrl RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.loadUrl(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","loadUrl","(Ljava/lang/String;Ljava/util/Map;)V","",1,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebView.loadUrl.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call loadUrl RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.loadUrl(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebView","loadUrl","(Ljava/lang/String;)V","",1,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var HttpURLConnectionImpl = Java.use('com.android.okhttp.internal.huc.HttpURLConnectionImpl');

                
            
                try{
                    HttpURLConnectionImpl.getInputStream.overload().implementation = function () {
                        writeFile("Hook call getInputStream INTERNET After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getInputStream();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;

                        
                        return fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"com.android.okhttp.internal.huc.HttpURLConnectionImpl","getInputStream","()Ljava/io/InputStream;","INTERNET",1,showStacks(),0)
                    }

                }catch(e){
                    writeFile(e)
                }
                try{
                     
                     HttpURLConnectionImpl.getOutputStream.overload().implementation = function () {
                     writeFile("Hook call HttpURLConnectionImpl getOutputStream INTERNET After");
                     
                    
                    
                    
                    
                    var HttpURLConnection_class = Java.use("java.net.HttpURLConnection");
                    var httpConn = Java.cast(this,HttpURLConnection_class);
                    var headers = httpConn.getRequestProperties();
                       

                    var arguments_list = Java.array("Ljava.lang.Object;",[]);

                    var ret = this.getOutputStream();
                    var this_Object = Java.cast(this,Object_class);
           
                    
                    
                    var ret_Object;
                    if(ret != null)
                        ret_Object = Java.cast(ret,Object_class);
                    else 
                        ret_Object = null;
                    var new_ret_Object = fridaManager.get().addDetailInfo_output("AFTER",arguments_list,this_Object,ret_Object,headers,"com.android.okhttp.internal.huc.HttpURLConnectionImpl","getOutputStream","()Ljava/io/OutputStream;","INTERNET",1,showStacks(),0)
                    return new_ret_Object;
                    }

                }catch(e){
                    writeFile(e)
                }   
            }catch(e){
                writeFile(e)
            }


            
            try{

                var ServerSocket = Java.use('java.net.ServerSocket');

                

                try{
                    ServerSocket.bind.overload('java.net.SocketAddress').implementation = function () {
                        writeFile("Hook call bind INTERNET Before");

                        var ret = this.bind(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"java.net.ServerSocket","bind","(Ljava/net/SocketAddress;)V","INTERNET",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var SmsManager = Java.use('android.telephony.gsm.SmsManager');

                

                try{
                    SmsManager.sendDataMessage.overload('java.lang.String','java.lang.String','short','[B','android.app.PendingIntent','android.app.PendingIntent').implementation = function () {
                        writeFile("Hook call sendDataMessage WAKE_LOCK Before");

                        var ret = this.sendDataMessage(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        var arguments_2_object = Short_class.$new(arguments[2])
                        
                        if (!isnull(arguments[3])){
                             var arguments_3_object = ArrayList_class.$new();
                             arguments[3].forEach( function(item){
                                arguments_3_object.add(item)
                             })

                        }else{
                            var arguments_3_object = arguments[3]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object,arguments_3_object,arguments[4],arguments[5]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.gsm.SmsManager","sendDataMessage","(Ljava/lang/String;Ljava/lang/String;S[BLandroid/app/PendingIntent;Landroid/app/PendingIntent;)V","SEND_SMS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    SmsManager.sendMultipartTextMessage.overload('java.lang.String','java.lang.String','java.util.ArrayList','java.util.ArrayList','java.util.ArrayList').implementation = function () {
                        writeFile("Hook call sendMultipartTextMessage WAKE_LOCK Before");

                        var ret = this.sendMultipartTextMessage(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.gsm.SmsManager","sendMultipartTextMessage","(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;)V","SEND_SMS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Contacts$People = Java.use('android.provider.Contacts$People');

                

                try{
                    Contacts$People.createPersonInMyContactsGroup.overload('android.content.ContentResolver','android.content.ContentValues').implementation = function () {
                        writeFile("Hook call createPersonInMyContactsGroup READ_CONTACTS Before");

                        var ret = this.createPersonInMyContactsGroup(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.Contacts$People","createPersonInMyContactsGroup","(Landroid/content/ContentResolver;Landroid/content/ContentValues;)Landroid/net/Uri;","READ_CONTACTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }

            try{
                var NetworkInterface = Java.use('java.net.NetworkInterface');
                try{
                    NetworkInterface.getHardwareAddress.overload().implementation = function () {
                        writeFile("Hook call getHardwareAddress INTERNET BEFORE");
                        var ret = this.getHardwareAddress();
                        var arguments_list = Java.array("Ljava.lang.Object;",[]);


                        

                        var this_Object = Java.cast(this,Object_class);
                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object, null,"java.net.NetworkInterface","getHardwareAddress","()[B","INTERNET",0,showStacks(),1)
                        return ret;
                    }
                }catch(e){
                    writeFile(e)
                }
            }catch(e){
                writeFile(e)
            }


            
            try{

                var WebIconDatabase = Java.use('android.webkit.WebIconDatabase');

                

                try{
                    WebIconDatabase.close.overload().implementation = function () {
                        writeFile("Hook call close ACCESS_NETWORK_STATE Before");

                        var ret = this.close();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","close","()V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebIconDatabase.open.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call open ACCESS_NETWORK_STATE Before");

                        var ret = this.open(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","open","(Ljava/lang/String;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebIconDatabase.releaseIconForPageUrl.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call releaseIconForPageUrl ACCESS_NETWORK_STATE Before");

                        var ret = this.releaseIconForPageUrl(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","releaseIconForPageUrl","(Ljava/lang/String;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebIconDatabase.removeAllIcons.overload().implementation = function () {
                        writeFile("Hook call removeAllIcons ACCESS_NETWORK_STATE Before");

                        var ret = this.removeAllIcons();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","removeAllIcons","()V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebIconDatabase.requestIconForPageUrl.overload('java.lang.String','android.webkit.WebIconDatabase$IconListener').implementation = function () {
                        writeFile("Hook call requestIconForPageUrl ACCESS_NETWORK_STATE Before");

                        var ret = this.requestIconForPageUrl(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","requestIconForPageUrl","(Ljava/lang/String;Landroid/webkit/WebIconDatabase$IconListener;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebIconDatabase.retainIconForPageUrl.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call retainIconForPageUrl ACCESS_NETWORK_STATE Before");

                        var ret = this.retainIconForPageUrl(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebIconDatabase","retainIconForPageUrl","(Ljava/lang/String;)V","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var TelephonyManager = Java.use('android.telephony.TelephonyManager');

                

                try{
                    TelephonyManager.getCellLocation.overload().implementation = function () {
                        writeFile("Hook call getCellLocation ACCESS_COARSE_LOCATION Before");

                        var ret = this.getCellLocation();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.TelephonyManager","getCellLocation","()Landroid/telephony/CellLocation;","ACCESS_COARSE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    TelephonyManager.getLine1Number.overload().implementation = function () {
                        writeFile("Hook call getLine1Number READ_PHONE_NUMBERS After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getLine1Number();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getLine1Number","()Ljava/lang/String;","READ_PHONE_NUMBERS",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    TelephonyManager.getNeighboringCellInfo.overload().implementation = function () {
                        writeFile("Hook call getNeighboringCellInfo ACCESS_FINE_LOCATION Before");

                        var ret = this.getNeighboringCellInfo();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.TelephonyManager","getNeighboringCellInfo","()Ljava/util/List;","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    TelephonyManager.getSimSerialNumber.overload().implementation = function () {
                        writeFile("Hook call getSimSerialNumber READ_PHONE_STATE After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getSimSerialNumber();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getSimSerialNumber","()Ljava/lang/String;","READ_PHONE_STATE",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    TelephonyManager.getSubscriberId.overload().implementation = function () {
                        writeFile("Hook call getSubscriberId READ_PHONE_STATE After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getSubscriberId();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getSubscriberId","()Ljava/lang/String;","READ_PHONE_STATE",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    TelephonyManager.getVoiceMailAlphaTag.overload().implementation = function () {
                        writeFile("Hook call getVoiceMailAlphaTag READ_PHONE_STATE After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getVoiceMailAlphaTag();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getVoiceMailAlphaTag","()Ljava/lang/String;","READ_PHONE_STATE",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    TelephonyManager.getVoiceMailNumber.overload().implementation = function () {
                        writeFile("Hook call getVoiceMailNumber READ_PHONE_STATE After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[]);

                        var ret = this.getVoiceMailNumber();

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = ret;
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getVoiceMailNumber","()Ljava/lang/String;","READ_PHONE_STATE",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    TelephonyManager.listen.overload('android.telephony.PhoneStateListener','int').implementation = function () {
                        writeFile("Hook call listen READ_PHONE_STATE Before");

                        var ret = this.listen(arguments[0],arguments[1]);

                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.TelephonyManager","listen","(Landroid/telephony/PhoneStateListener;I)V","READ_PHONE_STATE",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }

                try{
                TelephonyManager.getDeviceId.overload().implementation = function () {
                    writeFile("Hook call getDeviceId Before");
                    var ret = this.getDeviceId();
                    var arguments_list = Java.array("Ljava.lang.Object;",[]);
                    var this_Object = Java.cast(this,Object_class);
                    var ret_Object;
                    if(ret != null)
                        ret_Object = ret;
                    else
                        ret_Object = null;
                    fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.telephony.TelephonyManager","getDeviceId","()Ljava/lang/String;","READ_PHONE_STATE",0,showStacks(),1)
                    writeFile("Hook call getDeviceId over!");
                    return ret;

                }

                }catch(e){
                    writeFile(e)
                }


            }catch(e){
                writeFile(e)
            }


            
            try{

                var LocationManager = Java.use('android.location.LocationManager');

                

                try{
                    LocationManager.addGpsStatusListener.overload('android.location.GpsStatus$Listener').implementation = function () {
                        writeFile("Hook call addGpsStatusListener ACCESS_FINE_LOCATION Before");

                        var ret = this.addGpsStatusListener(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","addGpsStatusListener","(Landroid/location/GpsStatus$Listener;)Z","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.addNmeaListener.overload('android.location.GpsStatus$NmeaListener').implementation = function () {
                        writeFile("Hook call addNmeaListener ACCESS_FINE_LOCATION Before");

                        var ret = this.addNmeaListener(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","addNmeaListener","(Landroid/location/GpsStatus$NmeaListener;)Z","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.addTestProvider.overload('java.lang.String','boolean','boolean','boolean','boolean','boolean','boolean','boolean','int','int').implementation = function () {
                        writeFile("Hook call addTestProvider ACCESS_MOCK_LOCATION Before");

                        var ret = this.addTestProvider(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6],arguments[7],arguments[8],arguments[9]);

                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        var arguments_3_object = Boolean_class.$new(arguments[3])
                        var arguments_4_object = Boolean_class.$new(arguments[4])
                        var arguments_5_object = Boolean_class.$new(arguments[5])
                        var arguments_6_object = Boolean_class.$new(arguments[6])
                        var arguments_7_object = Boolean_class.$new(arguments[7])
                        var arguments_8_object = Integer_class.$new(arguments[8])
                        var arguments_9_object = Integer_class.$new(arguments[9])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments_2_object,arguments_3_object,arguments_4_object,arguments_5_object,arguments_6_object,arguments_7_object,arguments_8_object,arguments_9_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","addTestProvider","(Ljava/lang/String;ZZZZZZZII)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.clearTestProviderEnabled.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call clearTestProviderEnabled ACCESS_MOCK_LOCATION Before");

                        var ret = this.clearTestProviderEnabled(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","clearTestProviderEnabled","(Ljava/lang/String;)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.clearTestProviderLocation.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call clearTestProviderLocation ACCESS_MOCK_LOCATION Before");

                        var ret = this.clearTestProviderLocation(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","clearTestProviderLocation","(Ljava/lang/String;)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.clearTestProviderStatus.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call clearTestProviderStatus ACCESS_MOCK_LOCATION Before");

                        var ret = this.clearTestProviderStatus(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","clearTestProviderStatus","(Ljava/lang/String;)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.getBestProvider.overload('android.location.Criteria','boolean').implementation = function () {
                        writeFile("Hook call getBestProvider ACCESS_FINE_LOCATION Before");

                        var ret = this.getBestProvider(arguments[0],arguments[1]);

                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","getBestProvider","(Landroid/location/Criteria;Z)Ljava/lang/String;","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    LocationManager.getLastKnownLocation.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getLastKnownLocation ACCESS_FINE_LOCATION After");
                        
                        

                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);

                        var ret = this.getLastKnownLocation(arguments[0]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.location.LocationManager","getLastKnownLocation","(Ljava/lang/String;)Landroid/location/Location;","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.getProvider.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call getProvider ACCESS_FINE_LOCATION Before");

                        var ret = this.getProvider(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","getProvider","(Ljava/lang/String;)Landroid/location/LocationProvider;","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.getProviders.overload('boolean').implementation = function () {
                        writeFile("Hook call getProviders ACCESS_FINE_LOCATION Before");

                        var ret = this.getProviders(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","getProviders","(Z)Ljava/util/List;","ACCESS_FINE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.isProviderEnabled.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call isProviderEnabled ACCESS_FINE_LOCATION Before");

                        var ret = this.isProviderEnabled(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","isProviderEnabled","(Ljava/lang/String;)Z","",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.removeTestProvider.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call removeTestProvider ACCESS_MOCK_LOCATION Before");

                        var ret = this.removeTestProvider(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","removeTestProvider","(Ljava/lang/String;)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.sendExtraCommand.overload('java.lang.String','java.lang.String','android.os.Bundle').implementation = function () {
                        writeFile("Hook call sendExtraCommand ACCESS_LOCATION_EXTRA_COMMANDS Before");

                        var ret = this.sendExtraCommand(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","sendExtraCommand","(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Z","ACCESS_LOCATION_EXTRA_COMMANDS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.setTestProviderEnabled.overload('java.lang.String','boolean').implementation = function () {
                        writeFile("Hook call setTestProviderEnabled ACCESS_MOCK_LOCATION Before");

                        var ret = this.setTestProviderEnabled(arguments[0],arguments[1]);

                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","setTestProviderEnabled","(Ljava/lang/String;Z)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    LocationManager.setTestProviderLocation.overload('java.lang.String','android.location.Location').implementation = function () {
                        writeFile("Hook call setTestProviderLocation ACCESS_MOCK_LOCATION Before");

                        var ret = this.setTestProviderLocation(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.location.LocationManager","setTestProviderLocation","(Ljava/lang/String;Landroid/location/Location;)V","ACCESS_MOCK_LOCATION",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var GsmCellLocation = Java.use('android.telephony.gsm.GsmCellLocation');

                

                try{
                    GsmCellLocation.getCid.overload().implementation = function () {
                        writeFile("Hook call getCid ACCESS_COARSE_LOCATION Before");

                        var ret = this.getCid();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.gsm.GsmCellLocation","getCid","()I","ACCESS_COARSE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    GsmCellLocation.getLac.overload().implementation = function () {
                        writeFile("Hook call getLac ACCESS_COARSE_LOCATION Before");

                        var ret = this.getLac();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.telephony.gsm.GsmCellLocation","getLac","()I","ACCESS_COARSE_LOCATION",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ContactsContract$RawContacts = Java.use('android.provider.ContactsContract$RawContacts');

                

                try{
                    ContactsContract$RawContacts.getContactLookupUri.overload('android.content.ContentResolver','android.net.Uri').implementation = function () {
                        writeFile("Hook call getContactLookupUri READ_CONTACTS Before");

                        var ret = this.getContactLookupUri(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.provider.ContactsContract$RawContacts","getContactLookupUri","(Landroid/content/ContentResolver;Landroid/net/Uri;)Landroid/net/Uri;","READ_CONTACTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WifiManager$MulticastLock = Java.use('android.net.wifi.WifiManager$MulticastLock');

                

                try{
                    WifiManager$MulticastLock.acquire.overload().implementation = function () {
                        writeFile("Hook call acquire CHANGE_WIFI_MULTICAST_STATE Before");

                        var ret = this.acquire();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager$MulticastLock","acquire","()V","CHANGE_WIFI_MULTICAST_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WifiManager$MulticastLock.release.overload().implementation = function () {
                        writeFile("Hook call release CHANGE_WIFI_MULTICAST_STATE Before");

                        var ret = this.release();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.wifi.WifiManager$MulticastLock","release","()V","CHANGE_WIFI_MULTICAST_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var AsyncPlayer = Java.use('android.media.AsyncPlayer');

                

                try{
                    AsyncPlayer.play.overload('android.content.Context','android.net.Uri','boolean','int').implementation = function () {
                        writeFile("Hook call play WAKE_LOCK Before");

                        var ret = this.play(arguments[0],arguments[1],arguments[2],arguments[3]);

                        var arguments_2_object = Boolean_class.$new(arguments[2])
                        var arguments_3_object = Integer_class.$new(arguments[3])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments_2_object,arguments_3_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AsyncPlayer","play","(Landroid/content/Context;Landroid/net/Uri;ZI)V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    AsyncPlayer.stop.overload().implementation = function () {
                        writeFile("Hook call stop WAKE_LOCK Before");

                        var ret = this.stop();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.media.AsyncPlayer","stop","()V","WAKE_LOCK",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var KeyguardManager$KeyguardLock = Java.use('android.app.KeyguardManager$KeyguardLock');

                

                try{
                    KeyguardManager$KeyguardLock.disableKeyguard.overload().implementation = function () {
                        writeFile("Hook call disableKeyguard DISABLE_KEYGUARD Before");

                        var ret = this.disableKeyguard();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.KeyguardManager$KeyguardLock","disableKeyguard","()V","DISABLE_KEYGUARD",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    KeyguardManager$KeyguardLock.reenableKeyguard.overload().implementation = function () {
                        writeFile("Hook call reenableKeyguard DISABLE_KEYGUARD Before");

                        var ret = this.reenableKeyguard();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.KeyguardManager$KeyguardLock","reenableKeyguard","()V","DISABLE_KEYGUARD",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ConnectivityManager = Java.use('android.net.ConnectivityManager');

                

                try{
                    ConnectivityManager.getNetworkInfo.overload('int').implementation = function () {
                        writeFile("Hook call getNetworkInfo ACCESS_NETWORK_STATE Before");

                        var ret = this.getNetworkInfo(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","getNetworkInfo","(I)Landroid/net/NetworkInfo;","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ConnectivityManager.getNetworkPreference.overload().implementation = function () {
                        writeFile("Hook call getNetworkPreference ACCESS_NETWORK_STATE Before");

                        var ret = this.getNetworkPreference();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","getNetworkPreference","()I","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ConnectivityManager.requestRouteToHost.overload('int','int').implementation = function () {
                        writeFile("Hook call requestRouteToHost CHANGE_NETWORK_STATE Before");

                        var ret = this.requestRouteToHost(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","requestRouteToHost","(II)Z","CHANGE_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ConnectivityManager.setNetworkPreference.overload('int').implementation = function () {
                        writeFile("Hook call setNetworkPreference WRITE_SETTINGS Before");

                        var ret = this.setNetworkPreference(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","setNetworkPreference","(I)V","WRITE_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ConnectivityManager.startUsingNetworkFeature.overload('int','java.lang.String').implementation = function () {
                        writeFile("Hook call startUsingNetworkFeature ACCESS_NETWORK_STATE Before");

                        var ret = this.startUsingNetworkFeature(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","startUsingNetworkFeature","(ILjava/lang/String;)I","ACCESS_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ConnectivityManager.stopUsingNetworkFeature.overload('int','java.lang.String').implementation = function () {
                        writeFile("Hook call stopUsingNetworkFeature CHANGE_NETWORK_STATE Before");

                        var ret = this.stopUsingNetworkFeature(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.net.ConnectivityManager","stopUsingNetworkFeature","(ILjava/lang/String;)I","CHANGE_NETWORK_STATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ActivityManager = Java.use('android.app.ActivityManager');

                

                try{
                    ActivityManager.getRecentTasks.overload('int','int').implementation = function () {
                        writeFile("Hook call getRecentTasks GET_TASKS Before");

                        var ret = this.getRecentTasks(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.ActivityManager","getRecentTasks","(II)Ljava/util/List;","GET_TASKS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ActivityManager.getRunningTasks.overload('int').implementation = function () {
                        writeFile("Hook call getRunningTasks GET_TASKS Before");

                        var ret = this.getRunningTasks(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.ActivityManager","getRunningTasks","(I)Ljava/util/List;","GET_TASKS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ActivityManager.killBackgroundProcesses.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call killBackgroundProcesses KILL_BACKGROUND_PROCESSES Before");

                        var ret = this.killBackgroundProcesses(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.ActivityManager","killBackgroundProcesses","(Ljava/lang/String;)V","KILL_BACKGROUND_PROCESSES",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ActivityManager.restartPackage.overload('java.lang.String').implementation = function () {
                        writeFile("Hook call restartPackage KILL_BACKGROUND_PROCESSES Before");

                        var ret = this.restartPackage(arguments[0]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.app.ActivityManager","restartPackage","(Ljava/lang/String;)V","KILL_BACKGROUND_PROCESSES",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var QuickContactBadge = Java.use('android.widget.QuickContactBadge');

                

                try{
                    QuickContactBadge.assignContactFromPhone.overload('java.lang.String','boolean').implementation = function () {
                        writeFile("Hook call assignContactFromPhone READ_CONTACTS Before");

                        var ret = this.assignContactFromPhone(arguments[0],arguments[1]);

                        var arguments_1_object = Boolean_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.widget.QuickContactBadge","assignContactFromPhone","(Ljava/lang/String;Z)V","READ_CONTACTS",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var ContentResolver = Java.use('android.content.ContentResolver');

                
            
                try{
                    ContentResolver.query.overload('android.net.Uri','[Ljava.lang.String;','java.lang.String','[Ljava.lang.String;','java.lang.String','android.os.CancellationSignal').implementation = function () {
                        writeFile("Hook call query CONTENTRESOLVER_QUERY After");
                        
                        
                        if (!isnull(arguments[1])){
                             var arguments_1_object = ArrayList_class.$new();
                             arguments[1].forEach( function(item){
                                arguments_1_object.add(item)
                             })

                        }else{
                            var arguments_1_object = arguments[1]
                        }


                        if (!isnull(arguments[3])){
                             var arguments_3_object = ArrayList_class.$new();
                             arguments[3].forEach( function(item){
                                arguments_3_object.add(item)
                             })

                        }else{
                            var arguments_3_object = arguments[3]
                        }



                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2],arguments_3_object,arguments[4],arguments[5]]);

                        var ret = this.query(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.content.ContentResolver","query","(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;","CONTENTRESOLVER_QUERY",0,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.getIsSyncable.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call getIsSyncable READ_SYNC_SETTINGS Before");

                        var ret = this.getIsSyncable(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","getIsSyncable","(Landroid/accounts/Account;Ljava/lang/String;)I","READ_SYNC_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.getMasterSyncAutomatically.overload().implementation = function () {
                        writeFile("Hook call getMasterSyncAutomatically READ_SYNC_SETTINGS Before");

                        var ret = this.getMasterSyncAutomatically();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","getMasterSyncAutomatically","()Z","READ_SYNC_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.getPeriodicSyncs.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call getPeriodicSyncs READ_SYNC_SETTINGS Before");

                        var ret = this.getPeriodicSyncs(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","getPeriodicSyncs","(Landroid/accounts/Account;Ljava/lang/String;)Ljava/util/List;","READ_SYNC_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.getSyncAutomatically.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call getSyncAutomatically READ_SYNC_SETTINGS Before");

                        var ret = this.getSyncAutomatically(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","getSyncAutomatically","(Landroid/accounts/Account;Ljava/lang/String;)Z","READ_SYNC_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.isSyncActive.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call isSyncActive READ_SYNC_STATS Before");

                        var ret = this.isSyncActive(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","isSyncActive","(Landroid/accounts/Account;Ljava/lang/String;)Z","READ_SYNC_STATS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.isSyncPending.overload('android.accounts.Account','java.lang.String').implementation = function () {
                        writeFile("Hook call isSyncPending READ_SYNC_STATS Before");

                        var ret = this.isSyncPending(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","isSyncPending","(Landroid/accounts/Account;Ljava/lang/String;)Z","READ_SYNC_STATS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.setMasterSyncAutomatically.overload('boolean').implementation = function () {
                        writeFile("Hook call setMasterSyncAutomatically WRITE_SYNC_SETTINGS Before");

                        var ret = this.setMasterSyncAutomatically(arguments[0]);

                        var arguments_0_object = Boolean_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","setMasterSyncAutomatically","(Z)V","WRITE_SYNC_SETTINGS",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.applyBatch.overload('java.lang.String','java.util.ArrayList').implementation = function () {
                        writeFile("Hook call applyBatch CONTENTRESOLVER_APPLYBATCH Before");

                        var ret = this.applyBatch(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","applyBatch","(Ljava/lang/String;Ljava/util/ArrayList;)[Landroid/content/ContentProviderResult;","CONTENTRESOLVER_APPLYBATCH",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.insert.overload('android.net.Uri','android.content.ContentValues').implementation = function () {
                        writeFile("Hook call insert CONTENTRESOLVER_INSERT Before");

                        var ret = this.insert(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","insert","(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;","CONTENTRESOLVER_INSERT",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }


            
                try{
                    ContentResolver.query.overload('android.net.Uri','[Ljava.lang.String;','java.lang.String','[Ljava.lang.String;','java.lang.String','android.os.CancellationSignal').implementation = function () {
                        writeFile("Hook call query CONTENTRESOLVER_QUERY After");
                        
                        
                        if (!isnull(arguments[1])){
                             var arguments_1_object = ArrayList_class.$new();
                             arguments[1].forEach( function(item){
                                arguments_1_object.add(item)
                             })

                        }else{
                            var arguments_1_object = arguments[1]
                        }


                        if (!isnull(arguments[3])){
                             var arguments_3_object = ArrayList_class.$new();
                             arguments[3].forEach( function(item){
                                arguments_3_object.add(item)
                             })

                        }else{
                            var arguments_3_object = arguments[3]
                        }



                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments_1_object,arguments[2],arguments_3_object,arguments[4],arguments[5]]);

                        var ret = this.query(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);

                        var this_Object = Java.cast(this,Object_class);
           
                        
                        
                        var ret_Object;
                        if(ret != null)
                            ret_Object = Java.cast(ret,Object_class);
                        else 
                            ret_Object = null;


                        
                        fridaManager.get().addDetailInfo("AFTER",arguments_list,this_Object,ret_Object,"android.content.ContentResolver","query","(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;","CONTENTRESOLVER_QUERY",0,showStacks(),0)

                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    ContentResolver.update.overload('android.net.Uri','android.content.ContentValues','java.lang.String','[Ljava.lang.String;').implementation = function () {
                        writeFile("Hook call update CONTENTRESOLVER_UPDATE Before");

                        var ret = this.update(arguments[0],arguments[1],arguments[2],arguments[3]);

                        
                        if (!isnull(arguments[3])){
                             var arguments_3_object = ArrayList_class.$new();
                             arguments[3].forEach( function(item){
                                arguments_3_object.add(item)
                             })

                        }else{
                            var arguments_3_object = arguments[3]
                        }




                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments_3_object]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.content.ContentResolver","update","(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I","CONTENTRESOLVER_UPDATE",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var WebViewClient = Java.use('android.webkit.WebViewClient');

                

                try{
                    WebViewClient.onReceivedHttpAuthRequest.overload('android.webkit.WebView','android.webkit.HttpAuthHandler','java.lang.String','java.lang.String').implementation = function () {
                        writeFile("Hook call onReceivedHttpAuthRequest RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.onReceivedHttpAuthRequest(arguments[0],arguments[1],arguments[2],arguments[3]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2],arguments[3]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebViewClient","onReceivedHttpAuthRequest","(Landroid/webkit/WebView;Landroid/webkit/HttpAuthHandler;Ljava/lang/String;Ljava/lang/String;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebViewClient.onReceivedSslError.overload('android.webkit.WebView','android.webkit.SslErrorHandler','android.net.http.SslError').implementation = function () {
                        writeFile("Hook call onReceivedSslError RECEIVE_BOOT_COMPLETED Before");

                        var ret = this.onReceivedSslError(arguments[0],arguments[1],arguments[2]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1],arguments[2]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebViewClient","onReceivedSslError","(Landroid/webkit/WebView;Landroid/webkit/SslErrorHandler;Landroid/net/http/SslError;)V","",0,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    WebViewClient.onPageFinished.overload('android.webkit.WebView','java.lang.String').implementation = function () {
                        writeFile("Hook call onPageFinished android.webkit.WebViewClien Before");

                        var ret = this.onPageFinished(arguments[0],arguments[1]);

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments[0],arguments[1]]);
                        var this_Object = Java.cast(this,Object_class);

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.webkit.WebViewClient","onPageFinished","(Landroid/webkit/WebView;Ljava/lang/String;)V","android.webkit.WebViewClien",1,showStacks(),0)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


            
            try{

                var Camera = Java.use('android.hardware.Camera');

                

                try{
                    Camera.open.overload().implementation = function () {
                        writeFile("Hook call open CAMERA Before");

                        var ret = this.open();

                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[]);
                        var this_Object = null;

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.Camera","open","()Landroid/hardware/Camera;","CAMERA",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Camera.open.overload('int').implementation = function () {
                        writeFile("Hook call open CAMERA Before");

                        var ret = this.open(arguments[0]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object]);
                        var this_Object = null;

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.Camera","open","(I)Landroid/hardware/Camera;","CAMERA",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



                try{
                    Camera.openLegacy.overload('int','int').implementation = function () {
                        writeFile("Hook call openLegacy CAMERA Before");

                        var ret = this.openLegacy(arguments[0],arguments[1]);

                        var arguments_0_object = Integer_class.$new(arguments[0])
                        var arguments_1_object = Integer_class.$new(arguments[1])
                        


                        var arguments_list = Java.array("Ljava.lang.Object;",[arguments_0_object,arguments_1_object]);
                        var this_Object = null;

                        fridaManager.get().addDetailInfo("BEFORE",arguments_list,this_Object,null,"android.hardware.Camera","openLegacy","(II)Landroid/hardware/Camera;","CAMERA",0,showStacks(),1)

                        


                        return ret;
                    }

                }catch(e){
                    writeFile(e)
                }



            }catch(e){
                writeFile(e)
            }


        });

}
}, 3000);
//setup();


//     setTimeout(function() {
//         setup();    
//     }, 10000);

// writeFile("load_all_class_timeout");
